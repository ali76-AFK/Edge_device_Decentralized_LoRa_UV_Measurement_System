import logging
import busio
import board
import digitalio
from adafruit_rfm9x import RFM9x

# Import from the unified config file
from hardware_config import LORA_FREQUENCY_MHZ, LORA_CS_PIN, LORA_RESET_PIN, LORA_DIO0_PIN

class LoRaComm:
    def __init__(self):
        # SPI bus
        spi = busio.SPI(board.SCK, MOSI=board.MOSI, MISO=board.MISO)

        # Control pins using dynamic board attribute lookup
        # This replaces the need for RPi.GPIO setup
        cs = digitalio.DigitalInOut(getattr(board, f"D{LORA_CS_PIN}"))
        reset = digitalio.DigitalInOut(getattr(board, f"D{LORA_RESET_PIN}"))

        # Setup DIO0 if defined (Using digitalio instead of RPi.GPIO)
        if LORA_DIO0_PIN is not None:
            self.dio0 = digitalio.DigitalInOut(getattr(board, f"D{LORA_DIO0_PIN}"))
            self.dio0.direction = digitalio.Direction.INPUT
            # Note: RFM9x polling mode (receive with timeout) usually doesn't strictly 
            # require the interrupt pin to be configured in Python, but we map it just in case.

        try:
            self.rfm9x = RFM9x(spi, cs, reset, LORA_FREQUENCY_MHZ)
            self.rfm9x.tx_power = 14
            logging.info("LoRa init OK at %.1f MHz", LORA_FREQUENCY_MHZ)
        except Exception as e:
            logging.exception("LoRa init failed: %s", e)
            raise

    def send(self, payload: bytes) -> None:
        self.rfm9x.send(payload)

    def receive(self, timeout_s: float):
        return self.rfm9x.receive(timeout=timeout_s)

    @property
    def last_rssi(self):
        """Returns the RSSI (signal strength) of the last received packet."""
        return self.rfm9x.last_rssi

    @property
    def last_snr(self):
        """Returns the SNR (Signal to Noise Ratio) of the last received packet."""
        try:
            return self.rfm9x.last_snr
        except AttributeError:
            return None