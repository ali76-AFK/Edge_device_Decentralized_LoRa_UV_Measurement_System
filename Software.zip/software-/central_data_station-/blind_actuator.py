import time
import logging
from gpiozero import AngularServo
from hardware_config import BLIND_PIN_BCM

# Servo Parameters
SERVO_OPEN_ANGLE = 0
SERVO_CLOSED_ANGLE = 90
SERVO_MOVE_DELAY_S = 0.4

class BlindActuator:
    """
    Servo-based blind actuator using gpiozero (Pi 5 compatible).
    """

    def __init__(self):
        # Initialize servo on the specified pin. 
        # min_angle=0, max_angle=180 matches standard servo range.
        try:
            self.servo = AngularServo(BLIND_PIN_BCM, min_angle=0, max_angle=180)
            # Detach immediately to prevent jitter on startup
            self.servo.detach() 
        except Exception as e:
            logging.error(f"Failed to init servo: {e}")
            self.servo = None
            
        self.closed = False

    def close(self):
        if not self.closed and self.servo:
            self.servo.angle = SERVO_CLOSED_ANGLE
            time.sleep(SERVO_MOVE_DELAY_S)
            self.servo.detach() # Turn off signal to stop jitter
            self.closed = True
            logging.info("Blind CLOSED")

    def open(self):
        if self.closed and self.servo:
            self.servo.angle = SERVO_OPEN_ANGLE
            time.sleep(SERVO_MOVE_DELAY_S)
            self.servo.detach() # Turn off signal to stop jitter
            self.closed = False
            logging.info("Blind OPEN")

    def stop(self):
        if self.servo:
            self.servo.close()