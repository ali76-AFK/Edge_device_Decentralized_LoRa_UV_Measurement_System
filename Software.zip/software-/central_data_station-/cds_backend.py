import time
import threading
import logging
from collections import deque
from datetime import datetime
from dataclasses import dataclass
from typing import Optional

from protocol import PacketType, encode_packet, decode_packet, ConfigData
from hardware_config import LORA_FREQUENCY_MHZ
from lora_comm import LoRaComm
from blind_actuator import BlindActuator

DEFAULT_CONFIG = ConfigData(
    time_interval_s=5.0,
    uv_threshold=6.0,
    offset_corr_v=0.0,
    smoothing_alpha=0.3
)

@dataclass
class ErrorPacket:
    timestamp: datetime
    error_type: str
    pkt_type: Optional[str]
    reason: str
    raw_hex: str

class CentralDataSystemBackend:
    def __init__(self, config: ConfigData | None = None):
        self.config = config or DEFAULT_CONFIG

        self.lora = LoRaComm()
        self.blinds = BlindActuator()

        # Threading Lock for Radio Access
        self.lora_lock = threading.Lock()

        # Data Logging
        self.uv_log: deque[tuple[datetime, float]] = deque(maxlen=256)
        self.error_log: deque[ErrorPacket] = deque(maxlen=256)
        
        # Telemetry State
        self.last_packet_time: datetime | None = datetime.now() # Start with current time to delay first warning
        self.last_packet_interval: float | None = None
        self.last_rssi: int | None = None
        self.last_snr: float | None = None
        self.packets_rx = 0
        self.packets_crc_error = 0

        # Sync events
        self._config_ack_event = threading.Event()
        self._sensor_is_active = threading.Event()

        self._stop = threading.Event()
        
        # Threads
        self._rx_thread = threading.Thread(target=self._rx_loop, daemon=True)
        self._rx_thread.start()
        
        # NEW: Watchdog thread to warn if sensor dies
        self._watchdog_thread = threading.Thread(target=self._watchdog_loop, daemon=True)
        self._watchdog_thread.start()

    def _extract_error_packet(self, error_type: str, reason: str, raw: bytes | None = None, pkt_type: PacketType | None = None) -> None:
        raw_hex = raw.hex() if isinstance(raw, (bytes, bytearray)) else ""
        pkt_type_str = pkt_type.value if pkt_type else None
        self.error_log.append(ErrorPacket(datetime.now(), error_type, pkt_type_str, reason, raw_hex))

    def get_error_log(self) -> list[dict]:
        return [{"timestamp": ep.timestamp, "error_type": ep.error_type, "pkt_type": ep.pkt_type, "reason": ep.reason, "raw_hex": ep.raw_hex} for ep in list(self.error_log)]

    def _update_telemetry(self):
        now = datetime.now()
        if self.last_packet_time:
            self.last_packet_interval = (now - self.last_packet_time).total_seconds()
        self.last_packet_time = now
        try:
            self.last_rssi = self.lora.last_rssi
            self.last_snr = self.lora.last_snr
        except:
            pass

    def _safe_send(self, payload: bytes):
        """Thread-safe send helper"""
        with self.lora_lock:
            self.lora.send(payload)

    def _handle_uv_packet(self, payload: dict, crc_ok: bool, raw: bytes):
        if not crc_ok:
            logging.warning("UV packet CRC error")
            self.packets_crc_error += 1
            self._extract_error_packet("CRC_ERROR", "CRC mismatch in UV_DATA", raw, PacketType.UV_DATA)
            self._safe_send(encode_packet(PacketType.UV_NACK, {"reason": "crc"}))
            return

        try:
            uv_index = float(payload["uv_index"])
        except (KeyError, ValueError) as e:
            logging.warning("Malformed UV payload: %s", e)
            self._extract_error_packet("BAD_PAYLOAD", f"Invalid uv_index: {e}", raw, PacketType.UV_DATA)
            self._safe_send(encode_packet(PacketType.UV_NACK, {"reason": "bad_payload"}))
            return

        self._update_telemetry()
        self._sensor_is_active.set()
        
        self.packets_rx += 1
        self.uv_log.append((self.last_packet_time, uv_index))
        logging.info("Received UV index: %.2f", uv_index)

        if uv_index >= self.config.uv_threshold:
            self.blinds.close()
        else:
            self.blinds.open()

        self._safe_send(encode_packet(PacketType.UV_ACK, {"ok": True}))

    def _watchdog_loop(self):
        """Monitors last packet time and logs warnings if sensor is silent."""
        last_warning_time = 0
        while not self._stop.is_set():
            time.sleep(1.0)
            if not self.last_packet_time:
                continue
                
            age = (datetime.now() - self.last_packet_time).total_seconds()
            
            # If silent for > 15 seconds (3x normal interval)
            if age > 15.0:
                # Log warning every 10 seconds to avoid flooding
                if time.time() - last_warning_time > 10.0:
                    logging.warning(f"SENSOR TIMEOUT: No data received for {int(age)} seconds!")
                    last_warning_time = time.time()

    # In cds_backend.py, find the _rx_loop method and UPDATE it:

    def _rx_loop(self):
        while not self._stop.is_set():
            with self.lora_lock:
                packet = self.lora.receive(timeout_s=0.5)
            
            time.sleep(0.05) 

            if packet is None:
                continue

            try:
                pkt_type, payload, crc_ok = decode_packet(packet)
            except Exception as e:
                logging.warning("Decode error: %s", e)
                continue

            # --- NEW: Check if CRC failed ---
            if not crc_ok:
                 self.packets_crc_error += 1
                 self._extract_error_packet("CRC_ERROR", "CRC Check Failed", packet, None)
                 continue

            # --- EXISTING HANDLERS ---
            if pkt_type == PacketType.UV_DATA:
                self._handle_uv_packet(payload, True, packet)

            elif pkt_type == PacketType.CONFIG_ACK:
                logging.info("Received CONFIG_ACK from sensor")
                self._config_ack_event.set()
                self._sensor_is_active.set() 

            elif pkt_type == PacketType.CONFIG_NACK:
                logging.warning("Received CONFIG_NACK from sensor")

            # --- NEW FIX FOR CASE 2: Handle Error Packets Explicitly ---
            elif pkt_type == PacketType.ERROR:
                error_code = payload.get("error_code", "UNKNOWN")
                msg = payload.get("message", "No message")
                logging.warning(f"REMOTE SENSOR ERROR: {error_code} - {msg}")
                # Pass this to the GUI log
                self._extract_error_packet(f"SENSOR_{error_code}", msg, packet, pkt_type)

            else:
                logging.info("Unexpected packet type: %s", pkt_type)
                self._extract_error_packet("UNEXPECTED_TYPE", f"Type: {pkt_type}", packet, pkt_type)

    def send_config(self, new_cfg: ConfigData) -> bool:
        self.config = new_cfg
        pkt = encode_packet(PacketType.CONFIG, new_cfg.to_dict())

        self._config_ack_event.clear()
        
        if self._sensor_is_active.is_set():
            logging.info("Sensor active. Skipping redundant config sync.")
            return True

        logging.info("Sending CONFIG packet...")
        
        with self.lora_lock:
            self.lora.send(pkt)

        for _ in range(30): 
            if self._config_ack_event.is_set():
                return True
            if self._sensor_is_active.is_set():
                logging.info("Received UV data while waiting for ACK. Sync success.")
                return True
            time.sleep(0.1)

        logging.warning("CONFIG_ACK timeout")
        return False

    def get_status(self) -> dict:
        now = datetime.now()
        age = (now - self.last_packet_time).total_seconds() if self.last_packet_time else None
        return {
            "uv_threshold": self.config.uv_threshold,
            "interval_s": self.config.time_interval_s,
            "last_uv": self.uv_log[-1][1] if self.uv_log else None,
            "blind_closed": self.blinds.closed,
            "packets_rx": self.packets_rx,
            "crc_errors": self.packets_crc_error,
            "age_s": age,
            "error_count": len(self.error_log),
        }

    def stop(self):
        self._stop.set()
        self._rx_thread.join(timeout=1.0)
        self._watchdog_thread.join(timeout=1.0)
        self.blinds.stop()
        logging.info("CDS backend stopped")