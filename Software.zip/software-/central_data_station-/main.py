#!/usr/bin/env python3
import logging
import time
from cds_backend import CentralDataSystemBackend
from ui_tk import CDSApp

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    logger = logging.getLogger(__name__)

    # Initialize Backend
    backend = CentralDataSystemBackend()

    # --- ROBUST HANDSHAKE SEQUENCE ---
    logger.info("Attempting to synchronize with Sensor Station...")
    
    start_success = False
    # Try to send CONFIG up to 5 times (approx 15 seconds total)
    for attempt in range(1, 6):
        logger.info(f"Broadcasting startup configuration (Attempt {attempt}/5)...")
        
        # send_config waits up to 3 seconds for ACK or incoming data
        if backend.send_config(backend.config):
            logger.info("SUCCESS: Sensor Station synchronized!")
            start_success = True
            break
        else:
            logger.warning("No ACK received. Retrying...")
            time.sleep(1)

    if not start_success:
        logger.warning("Could not sync with sensor. Starting GUI anyway (Sensor will use Defaults).")
    # --------------------------------------

    try:
        app = CDSApp(backend)
        # REMOVED: The lines accessing 'app.frames' caused the crash.
        # The new GUI automatically updates settings when you open the page.
        
        app.mainloop()
    finally:
        backend.stop()

if __name__ == "__main__":
    main()