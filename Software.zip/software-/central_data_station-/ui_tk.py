#!/usr/bin/env python3
"""
uv_dashboard.py
Tkinter GUI for the Central Data System (CDS).
Updated: Active Error Polling from Backend
"""

import time
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from protocol import ConfigData

# ---------------------------------------------------------------------
# App + pages
# ---------------------------------------------------------------------

class CDSApp(tk.Tk):
    def __init__(self, cds):
        super().__init__()
        self.title("Decentralised UV LoRa – Central Station")
        self.attributes("-fullscreen", True)
        self.configure(bg="#f5f7fb")
        self.bind("<Escape>", lambda event: self.attributes("-fullscreen", False))

        self.cds = cds
        
        # State
        self.is_node_connected = False
        self.last_log_state_connected = True 
        self.last_error_count = 0 # Track how many errors we've seen

        # Styles
        style = ttk.Style(self)
        try: style.theme_use("clam")
        except tk.TclError: pass

        style.configure("Header.TLabel", font=("Helvetica", 18, "bold"), background="#f5f7fb")
        style.configure("SubHeader.TLabel", font=("Helvetica", 13), foreground="#555555", background="#f5f7fb")
        style.configure("Nav.TButton", font=("Helvetica", 12, "bold"))

        # Container
        container = tk.Frame(self, bg="#f5f7fb")
        container.pack(fill="both", expand=True)
        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

        self.pages = {}
        for PageCls in (FrontPage, MeasurePage, ChartPage, StatusPage, SettingsPage, LoggerPage):
            page = PageCls(parent=container, app=self)
            self.pages[PageCls.__name__] = page
            page.grid(row=0, column=0, sticky="nsew")

        self.show_page("FrontPage")
        self.log_event("System", "Dashboard started.")
        
        # Start Background Loops
        self.watchdog_check()
        self.poll_backend_errors()

    def show_page(self, name):
        page = self.pages[name]
        page.tkraise()
        if hasattr(page, "on_show"): page.on_show()

    def go_measure(self): self.show_page("MeasurePage")
    def go_chart(self): self.show_page("ChartPage")
    def go_status(self): self.show_page("StatusPage")
    def go_settings(self): self.show_page("SettingsPage")
    def go_logger(self): self.show_page("LoggerPage")
    def go_home(self): self.show_page("FrontPage")

    def log_event(self, category, message, level="INFO"):
        if "LoggerPage" in self.pages:
            self.pages["LoggerPage"].add_log(category, message, level)

    def watchdog_check(self):
        """Checks if sensor is alive based on packet rx count"""
        timeout_sec = 15.0
        now = time.time()
        
        if not hasattr(self, '_wd_last_pkt_count'):
            self._wd_last_pkt_count = -1
            self._wd_last_rx_time = time.time()

        if self.cds.packets_rx > self._wd_last_pkt_count:
            self._wd_last_pkt_count = self.cds.packets_rx
            self._wd_last_rx_time = time.time()
            self.is_node_connected = True
        
        time_diff = now - self._wd_last_rx_time
        
        if time_diff > timeout_sec:
            self.is_node_connected = False
            if self.last_log_state_connected:
                self.log_event("Watchdog", f"Connection Lost! No data for {int(time_diff)}s", "ERROR")
                self.last_log_state_connected = False
        else:
            self.is_node_connected = True
            if not self.last_log_state_connected:
                self.log_event("Watchdog", "Connection Restored.", "SUCCESS")
                self.last_log_state_connected = True

        self.after(2000, self.watchdog_check)

    def poll_backend_errors(self):
        """
        Polls the backend for new error packets from the sensor.
        If the sensor sends PacketType.ERROR, it appears here.
        """
        # backend.error_log is a deque of ErrorPacket objects
        current_errors = list(self.cds.error_log) # Snapshot
        total_errors = len(current_errors)
        
        if total_errors > self.last_error_count:
            # We have new errors!
            new_items = total_errors - self.last_error_count
            # Get the last 'new_items' errors
            recent_errors = current_errors[-new_items:]
            
            for err in recent_errors:
                # Format: [Sensor] Hardware Failure (ADS1115 Disconnected)
                msg = f"{err.reason}"
                self.log_event(err.error_type, msg, "ERROR")
            
            self.last_error_count = total_errors
            
        # Check every 1 second
        self.after(1000, self.poll_backend_errors)

    def shutdown(self):
        if messagebox.askyesno("Shutdown", "Really shut down system?"):
            self.log_event("System", "Shutdown sequence initiated...")
            self.cds.stop()
            self.destroy()

class BasePage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg="#f5f7fb")
        self.app = app
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

    def create_nav_bar(self, parent, title: str):
        bar = tk.Frame(parent, bg="#f5f7fb")
        bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(10, 5), padx=20)
        bar.columnconfigure(0, weight=1)
        bar.columnconfigure(1, weight=0)
        lbl = ttk.Label(bar, text=title, style="Header.TLabel")
        lbl.grid(row=0, column=0, sticky="w")
        btn = ttk.Button(bar, text="Back", style="Nav.TButton", command=self.app.go_home)
        btn.grid(row=0, column=1, sticky="e")
        return bar

# ---------------------------------------------------------------------
# FrontPage (Standard)
# ---------------------------------------------------------------------
class FrontPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        grid = tk.Frame(self, bg="#f5f7fb")
        grid.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        grid.rowconfigure((0, 1, 2), weight=1) 
        grid.columnconfigure((0, 1), weight=1) 

        tk.Label(grid, text="Decentralised UV – Central Station",
            font=("Helvetica", 20, "bold"), bg="#f5f7fb", fg="#222222"
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))

        def tile(r, c, title, subtitle, bg, accent, icon, cmd):
            frame = tk.Frame(grid, bg=bg, bd=0, highlightthickness=0)
            frame.grid(row=r, column=c, padx=10, pady=10, sticky="nsew")
            frame.rowconfigure((0, 1, 2), weight=1)
            frame.columnconfigure(0, weight=1)
            icon_canvas = tk.Canvas(frame, width=70, height=70, bg=bg, highlightthickness=0, bd=0)
            icon_canvas.grid(row=0, column=0, pady=(20, 10))
            r0 = 30
            icon_canvas.create_oval(35-r0, 35-r0, 35+r0, 35+r0, fill=accent, outline=accent)
            icon_canvas.create_text(35, 35, text=icon, font=("Helvetica", 26), fill="white")
            tk.Label(frame, text=title, bg=bg, fg="#222222", font=("Helvetica", 18, "bold")).grid(row=1, column=0, pady=(0, 5))
            tk.Label(frame, text=subtitle, bg=bg, fg="#555555", font=("Helvetica", 12)).grid(row=2, column=0, pady=(0, 20))
            def on_click(event=None): cmd()
            for w in (frame, icon_canvas): w.bind("<Button-1>", on_click)

        tile(1, 0, "MEASURE", "Current Readings", "#e9fff2", "#00a83b", "📈", self.app.go_measure)
        tile(1, 1, "LIVE GRAPH", "UV Index vs Time", "#e5f1ff", "#0066ff", "📊", self.app.go_chart)
        tile(2, 0, "STATUS", "System Diagnostics", "#f5e9ff", "#a200ff", "✅", self.app.go_status)
        tile(2, 1, "SETTINGS", "Network + Sensor + UI", "#fff2dd", "#ff5a00", "⚙️", self.app.go_settings)
        tile(3, 0, "DATA LOGS", "Events & Errors", "#f3f4f6", "#4b5563", "📝", self.app.go_logger)
        tile(3, 1, "TURN OFF", "Shutdown System", "#ffe5e5", "#ff4d4f", "🛑", self.app.shutdown)

# ---------------------------------------------------------------------
# MeasurePage
# ---------------------------------------------------------------------
class MeasurePage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        content = tk.Frame(self, bg="#f5f7fb")
        content.grid(row=0, column=0, sticky="nsew")
        content.columnconfigure((0, 1), weight=1)
        content.rowconfigure((1, 2, 3, 4), weight=0)

        self.create_nav_bar(content, "Measure – Current Readings")
        self.card_labels = {}

        def card(row, col, title, key, unit, bg):
            frame = tk.Frame(content, bg=bg, bd=0, highlightthickness=0)
            frame.grid(row=row, column=col, sticky="nsew", padx=10, pady=8)
            frame.columnconfigure(0, weight=1)
            frame.columnconfigure(1, weight=0)
            tk.Label(frame, text=title, bg=bg, fg="#2563eb", font=("Helvetica", 13, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(10, 2), padx=15)
            val_lbl = tk.Label(frame, text="--", bg=bg, fg="#111827", font=("Helvetica", 16, "bold"))
            val_lbl.grid(row=1, column=0, sticky="w", padx=15)
            tk.Label(frame, text=unit, bg=bg, fg="#6b7280", font=("Helvetica", 11)).grid(row=1, column=1, sticky="e", padx=15)
            self.card_labels[key] = val_lbl

        card(1, 0, "UV Intensity", "uv", "Volts", "#e5f1ff")
        card(1, 1, "Timestamp", "timestamp", "", "#f9fafb")
        card(2, 0, "Signal Strength (RSSI)", "rssi", "dBm", "#f5e9ff")
        card(2, 1, "Signal-to-Noise Ratio", "snr", "dB", "#e9fff2")
        card(3, 0, "Blind Status", "blind_status", "", "#fff2dd")
        card(3, 1, "Total Measurements", "total", "", "#e5f1ff")

        frame_thr = tk.Frame(content, bg="#fffbeb", bd=0, highlightthickness=0)
        frame_thr.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=10, pady=(8, 12))
        frame_thr.columnconfigure(0, weight=1)
        frame_thr.columnconfigure(1, weight=0)
        tk.Label(frame_thr, text="UV Threshold", bg="#fffbeb", fg="#92400e", font=("Helvetica", 13, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(10, 2), padx=15)
        self.card_labels["threshold"] = tk.Label(frame_thr, text="--", bg="#fffbeb", fg="#111827", font=("Helvetica", 16, "bold"))
        self.card_labels["threshold"].grid(row=1, column=0, sticky="w", padx=15)
        tk.Label(frame_thr, text="Volts (Blind closes above this value)", bg="#fffbeb", fg="#6b7280", font=("Helvetica", 11)).grid(row=1, column=1, sticky="e", padx=15)

    def on_show(self): self._update_cards()

    def _update_cards(self):
        if self.app.pages["MeasurePage"] != self: return
        cds = self.app.cds
        if cds.uv_log:
            ts, uv = cds.uv_log[-1]
            self.card_labels["uv"].config(text=f"{uv:.3f}")
            self.card_labels["timestamp"].config(text=ts.strftime("%H:%M:%S"))
        else:
            self.card_labels["uv"].config(text="--")
            self.card_labels["timestamp"].config(text="--")
        
        if cds.last_rssi is not None: self.card_labels["rssi"].config(text=f"{cds.last_rssi:.0f}")
        else: self.card_labels["rssi"].config(text="--")
        if cds.last_snr is not None: self.card_labels["snr"].config(text=f"{cds.last_snr:+.1f}")
        else: self.card_labels["snr"].config(text="--")
        blind_text = "CLOSED" if cds.blinds.closed else "OPEN"
        self.card_labels["blind_status"].config(text=blind_text)
        self.card_labels["total"].config(text=str(len(cds.uv_log)))
        self.card_labels["threshold"].config(text=f"{cds.config.uv_threshold:.2f}")
        self.after(1000, self._update_cards)

# ---------------------------------------------------------------------
# ChartPage
# ---------------------------------------------------------------------
class ChartPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        root = tk.Frame(self, bg="#f5f7fb")
        root.grid(row=0, column=0, sticky="nsew")
        root.rowconfigure(1, weight=1)
        root.columnconfigure(0, weight=1)

        self.create_nav_bar(root, "Live Graph – UV Index")
        self.canvas = tk.Canvas(root, bg="white", highlightthickness=0)
        self.canvas.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))

    def on_show(self): self._draw_chart()

    def volt_to_index(self, voltage):
        uv_index = voltage * 4.0 
        if uv_index < 0: uv_index = 0
        return uv_index

    def _draw_chart(self):
        cvs = self.canvas
        cvs.delete("all")
        width = cvs.winfo_width() or 800
        height = cvs.winfo_height() or 350
        
        ml, mr, mt, mb = 60, 20, 30, 40
        x0, y0 = ml, mt
        x1, y1 = width - mr, height - mb

        cvs.create_rectangle(x0, y0, x1, y1, outline="#e5e7eb")

        data = list(self.app.cds.uv_log)
        if len(data) < 2:
            cvs.create_text(width//2, height//2, text="Waiting for data...", fill="#6b7280")
            self.after(5000, self._draw_chart)
            return

        values = [self.volt_to_index(v) for (_, v) in data]
        v_min = 0
        v_max = 12

        def xy(idx, val):
            t = idx / max(1, len(data) - 1)
            x = x0 + t * (x1 - x0)
            if val > v_max: val = v_max
            norm = (val - v_min) / (v_max - v_min)
            y = y1 - norm * (y1 - y0)
            return x, y

        for i in range(5):
            val = i * 3
            norm = (val - v_min) / (v_max - v_min)
            y = y1 - norm * (y1 - y0)
            cvs.create_line(x0, y, x1, y, fill="#e5e7eb", dash=(2, 3))
            cvs.create_text(x0 - 10, y, text=f"{val}", anchor="e", fill="#6b7280", font=("Helvetica", 9))

        step = max(1, len(data) // 6)
        for i in range(0, len(data), step):
            ts, _ = data[i]
            x, _ = xy(i, values[i])
            cvs.create_line(x, y1, x, y1 + 4, fill="#9ca3af")
            cvs.create_text(x, y1 + 15, text=ts.strftime("%H:%M:%S"), anchor="n", fill="#6b7280", font=("Helvetica", 9))

        cvs.create_text((x0 + x1) // 2, height - 10, text="Time", fill="#374151", font=("Helvetica", 11))
        cvs.create_text(15, (y0 + y1) // 2, text="UV Index", angle=90, fill="#374151", font=("Helvetica", 11))

        last = None
        for idx, val in enumerate(values):
            x, y = xy(idx, val)
            if last is not None:
                cvs.create_line(last[0], last[1], x, y, width=2, fill="#2563eb")
            cvs.create_oval(x - 3, y - 3, x + 3, y + 3, outline="", fill="#2563eb")
            last = (x, y)

        self.after(2000, self._draw_chart)

# ---------------------------------------------------------------------
# StatusPage
# ---------------------------------------------------------------------
class StatusPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        root = tk.Frame(self, bg="#f5f7fb")
        root.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        root.columnconfigure(0, weight=1)
        self.create_nav_bar(root, "Status – System Diagnostics")
        def status_card(row, title):
            frame = tk.Frame(root, bg="white", bd=0, highlightthickness=0)
            frame.grid(row=row, column=0, sticky="nsew", pady=10)
            frame.columnconfigure(0, weight=1)
            frame.columnconfigure(1, weight=1)
            header = tk.Frame(frame, bg="white")
            header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=20, pady=(15, 5))
            tk.Label(header, text=title, bg="white", fg="#111827", font=("Helvetica", 14, "bold")).pack(side="left")
            return frame

        self.card_lora = status_card(1, "LoRa Communication")
        self.lbl_last_pkt = tk.Label(self.card_lora, bg="white", font=("Helvetica", 11))
        self.lbl_interval = tk.Label(self.card_lora, bg="white", font=("Helvetica", 11))
        self.lbl_rssi = tk.Label(self.card_lora, bg="white", font=("Helvetica", 11))
        self.lbl_snr = tk.Label(self.card_lora, bg="white", font=("Helvetica", 11))
        self._add_row(self.card_lora, 1, "Last Packet:", self.lbl_last_pkt)
        self._add_row(self.card_lora, 2, "Packet Interval:", self.lbl_interval)
        self._add_row(self.card_lora, 3, "RSSI:", self.lbl_rssi)
        self._add_row(self.card_lora, 4, "SNR:", self.lbl_snr)

        self.card_perf = status_card(2, "Data Performance")
        self.lbl_rate = tk.Label(self.card_perf, bg="white", font=("Helvetica", 11))
        self.lbl_thr = tk.Label(self.card_perf, bg="white", font=("Helvetica", 11))
        self.lbl_loss = tk.Label(self.card_perf, bg="white", font=("Helvetica", 11))
        self._add_row(self.card_perf, 1, "Data Rate:", self.lbl_rate)
        self._add_row(self.card_perf, 2, "Throughput:", self.lbl_thr)
        self._add_row(self.card_perf, 3, "Packet Loss:", self.lbl_loss)

        self.card_node = status_card(3, "Sensor Node")
        self.lbl_power = tk.Label(self.card_node, bg="white", font=("Helvetica", 11))
        self.lbl_ads = tk.Label(self.card_node, bg="white", font=("Helvetica", 11))
        self.lbl_uv = tk.Label(self.card_node, bg="white", font=("Helvetica", 11))
        self.lbl_motor = tk.Label(self.card_node, bg="white", font=("Helvetica", 11))
        self._add_row(self.card_node, 1, "Power:", self.lbl_power)
        self._add_row(self.card_node, 2, "ADS1115:", self.lbl_ads)
        self._add_row(self.card_node, 3, "UV Sensor:", self.lbl_uv)
        self._add_row(self.card_node, 4, "Servo / Motor:", self.lbl_motor)

        self._last_packets = 0
        self._last_time = time.time()

    @staticmethod
    def _add_row(frame, row, label_text, value_label):
        tk.Label(frame, text=f"• {label_text}", bg="white", fg="#6b7280",
                 font=("Helvetica", 11)).grid(row=row, column=0, sticky="w", padx=25, pady=2)
        value_label.grid(row=row, column=1, sticky="e", padx=25, pady=2)

    def on_show(self): self._update_status()

    def _update_status(self):
        if self.app.pages["StatusPage"] != self: return
        cds = self.app.cds
        now = time.time()
        connected = self.app.is_node_connected

        if cds.last_packet_time:
            self.lbl_last_pkt.config(text=cds.last_packet_time.strftime("%H:%M:%S"), fg="#374151")
        else:
            self.lbl_last_pkt.config(text="No packets", fg="#374151")

        if connected:
             self.lbl_interval.config(text=f"{cds.last_packet_interval:.1f} s", fg="#374151")
             self.lbl_rssi.config(text=f"{cds.last_rssi:.0f} dBm", fg="#374151")
             self.lbl_snr.config(text=f"{cds.last_snr:+.1f} dB", fg="#374151")
        else:
             self.lbl_interval.config(text="TIMEOUT", fg="#ef4444")
             self.lbl_rssi.config(text="--", fg="#9ca3af")
             self.lbl_snr.config(text="--", fg="#9ca3af")

        dt = now - self._last_time
        if dt <= 0: dt = 1.0
        new_packets = cds.packets_rx - self._last_packets
        rate_pps = new_packets / dt
        rate_kbps = rate_pps * 8 * 6 / 1000.0 

        self.lbl_rate.config(text=f"{rate_kbps:.2f} kbps", fg="#374151")
        self.lbl_thr.config(text=f"{new_packets * 6 / dt * 60:.1f} bytes/min", fg="#374151")

        total = cds.packets_rx + cds.packets_crc_error
        if total > 0:
            loss_pct = (cds.packets_crc_error / total) * 100
            self.lbl_loss.config(text=f"{loss_pct:.1f} %", fg="#374151")
        else:
            self.lbl_loss.config(text="--", fg="#374151")

        if connected:
            color = "#16a34a" 
            self.lbl_power.config(text="5.1V OK", fg=color)
            self.lbl_ads.config(text="Active", fg=color)
            self.lbl_uv.config(text="Connected", fg=color)
            self.lbl_motor.config(text="Ready", fg=color)
        else:
            color = "#dc2626"
            self.lbl_power.config(text="Unknown", fg=color)
            self.lbl_ads.config(text="Offline", fg=color)
            self.lbl_uv.config(text="Disconnected", fg=color)
            self.lbl_motor.config(text="Offline", fg=color)

        self._last_packets = cds.packets_rx
        self._last_time = now
        self.after(2000, self._update_status)

# ---------------------------------------------------------------------
# SettingsPage (Unchanged)
# ---------------------------------------------------------------------
class SettingsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        root = tk.Frame(self, bg="#f5f7fb")
        root.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        root.columnconfigure(0, weight=1)
        self.create_nav_bar(root, "Settings – Node & LoRa Configuration")
        node_card = tk.Frame(root, bg="white")
        node_card.grid(row=1, column=0, sticky="nsew", pady=10)
        node_card.columnconfigure(1, weight=1)
        tk.Label(node_card, text="Node Configuration", bg="white", fg="#111827", font=("Helvetica", 14, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(15, 5))
        tk.Label(node_card, text="Select Node:", bg="white", fg="#6b7280", font=("Helvetica", 11)).grid(row=1, column=0, sticky="w", padx=20, pady=3)
        self.node_combo = ttk.Combobox(node_card, values=["Sensor-01"], state="readonly")
        self.node_combo.current(0)
        self.node_combo.grid(row=1, column=1, sticky="ew", padx=20, pady=3)
        tk.Label(node_card, text="Measurement Interval (seconds):", bg="white", fg="#6b7280", font=("Helvetica", 11)).grid(row=2, column=0, sticky="w", padx=20, pady=3)
        self.meas_interval_entry = ttk.Entry(node_card)
        self.meas_interval_entry.insert(0, "5")
        self.meas_interval_entry.grid(row=2, column=1, sticky="ew", padx=20, pady=3)
        tk.Label(node_card, text="UV Threshold (volts):", bg="white", fg="#6b7280", font=("Helvetica", 11)).grid(row=3, column=0, sticky="w", padx=20, pady=(3, 15))
        self.uv_threshold_entry = ttk.Entry(node_card)
        self.uv_threshold_entry.grid(row=3, column=1, sticky="ew", padx=20, pady=(3, 15))

        lora_card = tk.Frame(root, bg="white")
        lora_card.grid(row=2, column=0, sticky="nsew", pady=10)
        lora_card.columnconfigure(1, weight=1)
        tk.Label(lora_card, text="LoRa Modem Settings", bg="white", fg="#111827", font=("Helvetica", 14, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(15, 5))
        tk.Label(lora_card, text="Frequency:", bg="white", fg="#6b7280", font=("Helvetica", 11)).grid(row=1, column=0, sticky="w", padx=20, pady=3)
        tk.Label(lora_card, text="868 MHz (fixed)", bg="white", fg="#111827", font=("Helvetica", 11)).grid(row=1, column=1, sticky="w", padx=20, pady=3)
        tk.Label(lora_card, text="Spreading Factor:", bg="white", fg="#6b7280", font=("Helvetica", 11)).grid(row=2, column=0, sticky="w", padx=20, pady=3)
        self.sf_combo = ttk.Combobox(lora_card, values=[7, 8, 9, 10, 11, 12], state="readonly")
        self.sf_combo.current(0)
        self.sf_combo.grid(row=2, column=1, sticky="ew", padx=20, pady=3)
        tk.Label(lora_card, text="Bandwidth:", bg="white", fg="#6b7280", font=("Helvetica", 11)).grid(row=3, column=0, sticky="w", padx=20, pady=(3, 15))
        self.bw_combo = ttk.Combobox(lora_card, values=["125 kHz", "250 kHz", "500 kHz"], state="readonly")
        self.bw_combo.current(0)
        self.bw_combo.grid(row=3, column=1, sticky="ew", padx=20, pady=(3, 15))
        tk.Button(root, text="Save Settings", command=self._save_settings, font=("Helvetica", 12, "bold"), bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white", bd=0, relief="flat", padx=10, pady=6).grid(row=3, column=0, sticky="e", pady=(10, 0))

    def on_show(self):
        self.uv_threshold_entry.delete(0, tk.END)
        self.uv_threshold_entry.insert(0, f"{self.app.cds.config.uv_threshold:.2f}")
        self.meas_interval_entry.delete(0, tk.END)
        self.meas_interval_entry.insert(0, f"{self.app.cds.config.time_interval_s:.1f}")

    def _save_settings(self):
        try:
            thr = float(self.uv_threshold_entry.get())
            interval = float(self.meas_interval_entry.get())
        except ValueError:
            self.app.log_event("Settings", "Invalid input for Threshold or Interval", "ERROR")
            messagebox.showerror("Settings", "Threshold and Interval must be numbers.")
            return

        new_config = ConfigData(
            time_interval_s=interval,
            uv_threshold=thr,
            offset_corr_v=self.app.cds.config.offset_corr_v,
            smoothing_alpha=self.app.cds.config.smoothing_alpha
        )

        messagebox.showinfo("Sending", "Sending configuration to sensor...")
        self.app.log_event("Settings", f"Sending new config: Thr={thr}V, Int={interval}s")
        success = self.app.cds.send_config(new_config)
        
        if success:
            self.app.log_event("Settings", "Configuration acknowledged by sensor.", "SUCCESS")
            messagebox.showinfo("Success", "Settings saved and confirmed by sensor.")
        else:
            self.app.log_event("Settings", "Configuration timed out (no ACK).", "WARNING")
            messagebox.showwarning("Timeout", "Settings saved locally, but Sensor did not ACK.")

# ---------------------------------------------------------------------
# LoggerPage (Unchanged)
# ---------------------------------------------------------------------
class LoggerPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        root = tk.Frame(self, bg="#f5f7fb")
        root.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)
        self.create_nav_bar(root, "Data Logger – Events & Errors")
        text_frame = tk.Frame(root, bg="white", bd=1, relief="solid")
        text_frame.grid(row=1, column=0, sticky="nsew", pady=10)
        text_frame.columnconfigure(0, weight=1)
        text_frame.rowconfigure(0, weight=1)
        self.log_area = scrolledtext.ScrolledText(text_frame, state='disabled', font=("Consolas", 10), bg="#1e1e1e", fg="#d4d4d4")
        self.log_area.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        self.log_area.tag_config("INFO", foreground="#d4d4d4")
        self.log_area.tag_config("ERROR", foreground="#ff4d4f")
        self.log_area.tag_config("WARNING", foreground="#faad14")
        self.log_area.tag_config("SUCCESS", foreground="#52c41a")
        self.log_area.tag_config("TIMESTAMP", foreground="#569cd6")
        btn_frame = tk.Frame(root, bg="#f5f7fb")
        btn_frame.grid(row=2, column=0, sticky="ew")
        tk.Button(btn_frame, text="Clear Logs", command=self.clear_logs, font=("Helvetica", 10), bg="#e5e7eb", fg="black", bd=0, padx=10, pady=5).pack(side="right")

    def add_log(self, category, message, level="INFO"):
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.log_area.configure(state='normal')
        self.log_area.insert(tk.END, f"[{now_str}] ", "TIMESTAMP")
        self.log_area.insert(tk.END, f"[{category}] ")
        self.log_area.insert(tk.END, f"{message}\n", level)
        self.log_area.see(tk.END)
        self.log_area.configure(state='disabled')

    def clear_logs(self):
        self.log_area.configure(state='normal')
        self.log_area.delete('1.0', tk.END)
        self.log_area.configure(state='disabled')
        self.app.log_event("System", "Logs cleared.")