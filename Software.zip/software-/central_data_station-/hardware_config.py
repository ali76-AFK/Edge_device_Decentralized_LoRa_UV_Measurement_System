# hardware_config.py for SENSOR STATION

# LoRa Radio Frequency
LORA_FREQUENCY_MHZ = 868.0

# RFM95W Wiring (BCM Pin Numbers)
LORA_CS_PIN    = 18 
LORA_RESET_PIN = 23  
LORA_DIO0_PIN  = 5   

# Actuator / Sensor Pins
BLIND_PIN_BCM  = 25
LED_PIN_BCM    = 17  # Physical Pin 11