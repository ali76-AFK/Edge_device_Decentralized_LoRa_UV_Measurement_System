"""
Protocol module - Shared between Sensor Station and Central Station
Simple JSON + CRC32 protocol for LoRa communication
"""

import json
import zlib
from dataclasses import dataclass, asdict
from enum import Enum

class PacketType(str, Enum):
    """Enumeration of all packet types used in the system"""
    UV_DATA = "UV_DATA"          # sensor -> central, sends UV measurement
    UV_ACK = "UV_ACK"            # central -> sensor, confirms correct UV packet
    UV_NACK = "UV_NACK"          # central -> sensor, signals UV packet problem
    
    CONFIG = "CONFIG"            # central -> sensor, sends configuration
    CONFIG_ACK = "CONFIG_ACK"    # sensor -> central, confirms valid config
    CONFIG_NACK = "CONFIG_NACK"  # sensor -> central, config was invalid
    
    ERROR = "ERROR"              # sensor -> central, reports error

@dataclass
class ConfigData:
    """
    Configuration values shared between CDS and sensor node
    """
    time_interval_s: float = 5.0      # measurement/transmission interval [s]
    uv_threshold: float = 6.0         # threshold at which blind should close
    offset_corr_v: float = 0.0        # voltage offset correction for sensor
    smoothing_alpha: float = 0.3      # low-pass filter factor on sensor
    max_retries: int = 3              # max transmission retries

    def to_dict(self):
        """Convert dataclass to a plain dict for JSON encoding"""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ConfigData":
        base = cls()
        for k in base.__dict__.keys():
            if k in d:
                setattr(base, k, d[k])
        return base

def encode_packet(pkt_type: PacketType, payload: dict | None) -> bytes:
    """
    Encode packet to bytes with CRC32 wrapper
    """
    inner = {
        "type": pkt_type.value,
        "payload": payload or {},
    }
    # FORCE TIGHT JSON FORMATTING (separators)
    inner_bytes = json.dumps(inner, separators=(',', ':')).encode("utf-8")
    crc = zlib.crc32(inner_bytes) & 0xFFFFFFFF
    outer = {"data": inner, "crc": crc}
    return json.dumps(outer, separators=(',', ':')).encode("utf-8")

def decode_packet(raw: bytes):
    """
    Decode and CRC-check a packet
    """
    try:
        outer = json.loads(raw.decode("utf-8"))
        inner = outer["data"]
        crc_rx = outer["crc"]
        
        # RE-ENCODE WITH SAME FORMATTING TO VERIFY CRC
        inner_bytes = json.dumps(inner, separators=(',', ':')).encode("utf-8")
        crc_calc = zlib.crc32(inner_bytes) & 0xFFFFFFFF
        
        crc_ok = (crc_rx == crc_calc)
        pkt_type = PacketType(inner["type"])
        payload = inner["payload"]
        return pkt_type, payload, crc_ok
    except Exception:
        return None, None, False