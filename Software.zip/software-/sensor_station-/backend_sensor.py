"""
Backend Sensor Module
Handles ADC, UV sensor reading, filtering, and validation
"""

import time
import logging
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

class UVSensor:
    """
    UV sensor backend handling ADC reading, filtering, and validation
    Hardware: ADS1115 + GUVA-S12SD
    """
    
    # ADC Configuration
    ADC_CHANNEL = 0  # ADS1115 channel A0
    ADC_GAIN = 1     # +/- 4.096V range
    
    # UV Sensor Configuration (GUVA-S12SD)
    UV_SENSITIVITY = 0.1  # V per UV index unit
    UV_MAX_VALID = 20.0   # Maximum valid UV index
    UV_MAX_JUMP = 5.0     # Maximum allowed change between readings
    
    def __init__(self):
        """Initialize UV sensor backend"""
        self.adc = None
        self.uv_channel = None
        self._is_initialized = False
        
        # Filtering state
        self.uv_filtered = None
        self.last_valid_uv = None
        
        # Runtime parameters (will be updated by config)
        self.offset = 0.0
        self.alpha = 0.3
    
    def initialize(self) -> bool:
        """
        Initialize ADS1115 ADC module.
        Includes robust error handling and immediate test read.
        """
        try:
            # Initialize I2C (Re-init ensures recovery after disconnects)
            i2c = busio.I2C(board.SCL, board.SDA)
            
            # Create ADS1115 object
            self.adc = ADS.ADS1115(i2c)
            self.adc.gain = self.ADC_GAIN
            
            # Create analog input channel
            self.uv_channel = AnalogIn(self.adc, self.ADC_CHANNEL)
            
            # TEST READ: Confirm communication immediately
            _ = self.uv_channel.voltage
            
            self._is_initialized = True
            logger.info("UV sensor (ADS1115) initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"UV sensor initialization failed: {e}")
            self._is_initialized = False
            return False
    
    @property
    def is_initialized(self) -> bool:
        """Check if sensor is initialized"""
        return self._is_initialized
    
    def update_config(self, offset: float, alpha: float):
        """Update runtime configuration parameters"""
        self.offset = offset
        self.alpha = alpha
        logger.debug(f"UV sensor config updated: offset={offset}V, alpha={alpha}")
    
    def read_voltage(self) -> float:
        """
        Read raw voltage from UV sensor.
        Catches OSError to handle physical wire disconnection.
        """
        if not self._is_initialized:
            # Try to reconnect/re-init if previously failed
            if not self.initialize():
                logger.error("UV sensor not initialized")
                return -1.0
        
        try:
            return self.uv_channel.voltage
        except OSError as e:
            # This catches "Remote I/O Error" (e.g., SDA/SCL wire pulled)
            logger.error(f"Hardware Error (I2C): {e}")
            self._is_initialized = False # Force re-init next time
            return -1.0
        except Exception as e:
            logger.error(f"Failed to read UV voltage: {e}")
            return -1.0
    
    def apply_offset_correction(self, voltage: float) -> float:
        """Apply offset calibration to voltage"""
        return voltage - self.offset
    
    def apply_low_pass_filter(self, current_value: float) -> float:
        """Apply exponential low-pass filter"""
        if self.uv_filtered is None:
            self.uv_filtered = current_value
        else:
            self.uv_filtered = self.alpha * current_value + (1 - self.alpha) * self.uv_filtered
        
        return self.uv_filtered
    
    def voltage_to_uv_index(self, voltage: float) -> float:
        """Convert voltage to UV index using sensor sensitivity"""
        if voltage < 0:
            return -1.0
        return voltage / self.UV_SENSITIVITY
    
    def validate_uv_index(self, uv_index: float) -> Tuple[bool, str]:
        """Validate UV index reading"""
        # Check for negative values (Error codes from previous steps)
        if uv_index < 0:
            return False, "Sensor Read Failed (Negative/Offline)"
        
        # Check for out-of-range values
        if uv_index > self.UV_MAX_VALID:
            return False, f"UV index exceeds maximum ({self.UV_MAX_VALID})"
        
        # Check for large jumps (optional safety check)
        if self.last_valid_uv is not None:
            jump = abs(uv_index - self.last_valid_uv)
            if jump > self.UV_MAX_JUMP:
                 # We log it but might still accept it if real
                 pass 
        
        return True, ""
    
    def read_uv(self) -> Tuple[float, bool, str]:
        """
        Complete UV reading pipeline:
        1. Read ADC voltage (Handle Disconnects)
        2. Apply offset correction
        3. Apply low-pass filter
        4. Convert to UV index
        5. Validate UV index
        """
        # Step 1: Read ADC voltage
        raw_voltage = self.read_voltage()
        
        # Immediate fail if hardware error
        if raw_voltage < 0:
            return -1.0, False, "Hardware Failure (ADS1115 Disconnected)"

        # --- NEW FIX FOR CASE 1: Sanity Check ---
        # If voltage is > 3.3V, the wire is likely floating or shorted to 5V.
        # Valid UV sensor output is usually 0V to ~1.2V (Index 12) or max 3.0V.
        if raw_voltage > 3.3:
             return -1.0, False, f"Sensor Fault: Voltage Too High ({raw_voltage:.2f}V)"
             
        # Step 2: Apply offset correction
        corrected_voltage = self.apply_offset_correction(raw_voltage)
        
        # Step 3: Apply low-pass filter
        filtered_voltage = self.apply_low_pass_filter(corrected_voltage)
        
        # Step 4: Convert to UV index
        uv_index = self.voltage_to_uv_index(filtered_voltage)
        
        # Step 5: Validate UV index
        is_valid, error_msg = self.validate_uv_index(uv_index)
        
        if is_valid:
            self.last_valid_uv = uv_index
            logger.debug(f"UV reading: {uv_index:.2f} (voltage: {filtered_voltage:.3f}V)")
        else:
            logger.warning(f"Invalid UV reading: {uv_index:.2f} - {error_msg}")
        
        return uv_index, is_valid, error_msg
    
    def reset_filter(self):
        """Reset low-pass filter state"""
        self.uv_filtered = None
        logger.debug("UV filter reset")
    
    def cleanup(self):
        """Cleanup resources"""
        self._is_initialized = False
        logger.info("UV sensor cleanup complete")