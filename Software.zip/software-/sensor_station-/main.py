#!/usr/bin/env python3
"""
Sensor Station Main Application
LoRa-based UV Monitoring System - Sensor Pi
Modular architecture with protocol matching Central Pi
"""

import time
import sys
import logging
import threading
import board
import digitalio
from protocol import PacketType, ConfigData, encode_packet, decode_packet
from lora_driver import LoRaDriver
from backend_sensor import UVSensor
from datetime import datetime

# Import LED pin from unified config
from hardware_config import LED_PIN_BCM


# ============================================================================
# CONSTANTS AND CONFIGURATION
# ============================================================================

# Sensor Identification
SENSOR_ID = "sensor1"

# LED Configuration
LED_PIN = board.D17              # GPIO 17 for status LED
LED_ERROR_BLINK_RATE = 0.2       # seconds (fast blink for errors)
LED_NORMAL_STATE = True          # ON during normal operation

# CONFIG Packet Handling
CONFIG_TIMEOUT = 30              # seconds to wait for initial CONFIG
CONFIG_MAX_ATTEMPTS = 3          # Max attempts to receive CONFIG on boot

# ACK/NACK Timeouts
ACK_TIMEOUT = 5.0                # seconds to wait for ACK

# Error Logging
ERROR_LOG_FILE = "sensor_station_errors.log"

# Default Runtime Parameters (updated by CONFIG packet)
DEFAULT_CONFIG = ConfigData(
    time_interval_s=5.0,
    uv_threshold=6.0,
    offset_corr_v=0.0,
    smoothing_alpha=0.3,
    max_retries=3
)


# ============================================================================
# LOGGING SETUP
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        # CHANGE THIS LINE BELOW: Use simple filename, no /home/ paths
        logging.FileHandler('sensor_station.log')
    ]
)
logger = logging.getLogger(__name__)


# ============================================================================
# GLOBAL STATE
# ============================================================================

class SensorStation:
    """Main sensor station controller"""
    
    def __init__(self):
        """Initialize sensor station"""
        self.lora = LoRaDriver()
        self.uv_sensor = UVSensor()
        self.led = None
        
        # Runtime configuration
        self.config = DEFAULT_CONFIG
        self.config_lock = threading.Lock()
        
        # Error tracking
        self.error_state = False
        self.error_log = []
        
        # Threading
        self.stop_event = threading.Event()
        self.error_led_thread = None
    
    # ========================================================================
    # LED CONTROL
    # ========================================================================
    
    def init_led(self) -> bool:
        """Initialize LED GPIO pin"""
        try:
            self.led = digitalio.DigitalInOut(getattr(board, f"D{LED_PIN_BCM}"))
            self.led.direction = digitalio.Direction.OUTPUT
            self.led.value = False
            return True
        except Exception as e:
            logging.error(f"LED init failed: {e}")
            return False
    
    def set_led(self, state: bool):
        """Set LED state (ON/OFF)"""
        if self.led:
            try:
                self.led.value = state
            except Exception as e:
                logger.error(f"LED control error: {e}")
    
    def blink_led_error(self, duration: float = 5.0):
        """Blink LED rapidly to indicate error"""
        if not self.led:
            return
        
        end_time = time.time() + duration
        while time.time() < end_time:
            self.set_led(True)
            time.sleep(LED_ERROR_BLINK_RATE)
            self.set_led(False)
            time.sleep(LED_ERROR_BLINK_RATE)
    
    def _led_error_loop(self):
        """Background thread for continuous error LED blinking"""
        while not self.stop_event.is_set():
            self.set_led(True)
            time.sleep(LED_ERROR_BLINK_RATE)
            self.set_led(False)
            time.sleep(LED_ERROR_BLINK_RATE)
    
    def start_error_led(self):
        """Start continuous error LED blinking in background"""
        if self.error_led_thread is None or not self.error_led_thread.is_alive():
            self.stop_event.clear()
            self.error_led_thread = threading.Thread(target=self._led_error_loop)
            self.error_led_thread.daemon = True
            self.error_led_thread.start()
    
    # ========================================================================
    # ERROR HANDLING
    # ========================================================================
    
    def log_error(self, error_code: str, message: str):
        """Log error to persistent storage"""
        timestamp = datetime.now().isoformat()
        error_entry = f"{timestamp} | {error_code} | {message}\n"
        
        try:
            with open(ERROR_LOG_FILE, 'a') as f:
                f.write(error_entry)
            self.error_log.append({'ts': timestamp, 'code': error_code, 'msg': message})
            logger.error(f"Error logged: {error_code} - {message}")
        except Exception as e:
            logger.error(f"Failed to write error log: {e}")
    
    def handle_critical_error(self, error_code: str, message: str):
        """Handle critical errors that prevent normal operation"""
        self.error_state = True
        logger.critical(f"Critical error: {error_code} - {message}")
        self.log_error(error_code, message)
        
        # Start continuous error LED blinking
        self.start_error_led()
        
        # Try to send error packet if LoRa is available
        if self.lora.is_initialized and error_code != "LORA_INIT_FAIL":
            try:
                error_packet = self.create_error_packet(error_code, message)
                self.lora.send(error_packet)
            except:
                pass
        
        # Stay in error state
        logger.info("Entering error state - LED blinking continuously")
    
    # ========================================================================
    # PACKET CREATION
    # ========================================================================
    
    def create_uv_packet(self, uv_index: float) -> bytes:
        """Create UV data packet"""
        timestamp = int(time.time())
        payload = {
            "sensor_id": SENSOR_ID,
            "uv_index": round(uv_index, 2),
            "timestamp": timestamp
        }
        return encode_packet(PacketType.UV_DATA, payload)
    
    def create_error_packet(self, error_code: str, message: str) -> bytes:
        """Create error packet"""
        timestamp = int(time.time())
        payload = {
            "sensor_id": SENSOR_ID,
            "error_code": error_code,
            "message": message,
            "timestamp": timestamp
        }
        return encode_packet(PacketType.ERROR, payload)
    
    def create_config_ack(self) -> bytes:
        """Create CONFIG acknowledgment packet"""
        payload = {"sensor_id": SENSOR_ID}
        return encode_packet(PacketType.CONFIG_ACK, payload)
    
    def create_config_nack(self, reason: str) -> bytes:
        """Create CONFIG negative acknowledgment packet"""
        payload = {"sensor_id": SENSOR_ID, "reason": reason}
        return encode_packet(PacketType.CONFIG_NACK, payload)
    
    # ========================================================================
    # CONFIG HANDLING
    # ========================================================================
    
    def parse_config_packet(self, payload: dict) -> ConfigData | None:
        """Parse and validate CONFIG packet payload"""
        try:
            config = ConfigData.from_dict(payload)
            
            # Validate ranges
            if config.time_interval_s <= 0 or config.time_interval_s > 3600:
                logger.error("Invalid interval value")
                return None
            if config.smoothing_alpha <= 0 or config.smoothing_alpha > 1:
                logger.error("Invalid alpha value")
                return None
            if config.max_retries < 1 or config.max_retries > 10:
                logger.error("Invalid max_retries value")
                return None
            
            logger.info(f"Parsed CONFIG: interval={config.time_interval_s}s, "
                       f"alpha={config.smoothing_alpha}, offset={config.offset_corr_v}V")
            return config
            
        except Exception as e:
            logger.error(f"Failed to parse CONFIG: {e}")
            return None
    
    def apply_config(self, config: ConfigData):
        """Apply configuration to runtime"""
        with self.config_lock:
            self.config = config
        
        # Update UV sensor parameters
        self.uv_sensor.update_config(config.offset_corr_v, config.smoothing_alpha)
        
        logger.info(f"Applied new configuration: {config.to_dict()}")
    
    def wait_for_initial_config(self) -> bool:
        """Wait for initial CONFIG packet on boot"""
        for attempt in range(1, CONFIG_MAX_ATTEMPTS + 1):
            logger.info(f"Waiting for CONFIG packet (attempt {attempt}/{CONFIG_MAX_ATTEMPTS})...")
            
            packet_bytes = self.lora.receive(timeout=CONFIG_TIMEOUT)
            
            if packet_bytes is None:
                logger.warning(f"CONFIG timeout on attempt {attempt}")
                self.blink_led_error(duration=2.0)
                continue
            
            # Decode packet
            pkt_type, payload, crc_ok = decode_packet(packet_bytes)
            
            if not crc_ok:
                logger.warning("Received packet with invalid CRC")
                continue
            
            if pkt_type == PacketType.CONFIG:
                config = self.parse_config_packet(payload)
                
                if config:
                    self.apply_config(config)
                    self.lora.send(self.create_config_ack())
                    logger.info("Initial CONFIG received and applied")
                    self.set_led(LED_NORMAL_STATE)
                    return True
                else:
                    self.lora.send(self.create_config_nack("Invalid format"))
                    continue
            else:
                logger.warning(f"Unexpected packet type (waiting for CONFIG): {pkt_type}")
        
        # === MODIFIED SECTION START ===
        logger.warning(f"Failed to receive valid CONFIG after {CONFIG_MAX_ATTEMPTS} attempts. Using DEFAULT_CONFIG.")
        self.set_led(LED_NORMAL_STATE)
        return True  # Proceed with default config instead of failing
        # === MODIFIED SECTION END ===
    
    def poll_for_config_update(self) -> bool:
        """Non-blocking check for CONFIG update packets"""
        packet_bytes = self.lora.receive(timeout=0.1)  # Short timeout
        
        if packet_bytes is None:
            return False
        
        pkt_type, payload, crc_ok = decode_packet(packet_bytes)
        
        if not crc_ok:
            return False
        
        if pkt_type == PacketType.CONFIG:
            logger.info("CONFIG update received during runtime")
            config = self.parse_config_packet(payload)
            
            if config:
                self.apply_config(config)
                self.lora.send(self.create_config_ack())
                logger.info("Runtime CONFIG update applied")
                return True
            else:
                self.lora.send(self.create_config_nack("Invalid format"))
        
        return False
    
    # ========================================================================
    # UV TRANSMISSION
    # ========================================================================
    
    def check_ack(self, response_bytes: bytes) -> bool:
        """Check if response is an ACK"""
        pkt_type, payload, crc_ok = decode_packet(response_bytes)
        if not crc_ok:
            return False
        return pkt_type == PacketType.UV_ACK
    
    def send_uv_with_ack(self, uv_index: float) -> bool:
        """Send UV packet and wait for ACK with retry logic"""
        with self.config_lock:
            max_retries = self.config.max_retries
        
        uv_packet = self.create_uv_packet(uv_index)
        
        success = self.lora.send_with_ack(
            uv_packet,
            max_retries,
            self.check_ack,
            ACK_TIMEOUT
        )
        
        if not success:
            logger.error("Failed to receive ACK for UV packet")
            error_packet = self.create_error_packet("NO_ACK", "UV ACK failed after retries")
            self.lora.send(error_packet)
            self.log_error("NO_ACK", f"UV packet failed after {max_retries} attempts")
            self.blink_led_error(duration=3.0)
        
        return success
    
    # ========================================================================
    # MAIN LOOP
    # ========================================================================
    
    def main_loop(self):
        """Main operational loop"""
        logger.info("Entering main operational loop")
        self.set_led(LED_NORMAL_STATE)
        
        while not self.error_state:
            try:
                loop_start = time.time()
                
                with self.config_lock:
                    interval = self.config.time_interval_s
                
                # 1. Poll for CONFIG updates (non-blocking)
                self.poll_for_config_update()
                
                # 2. Read and process UV
                uv_index, is_valid, error_msg = self.uv_sensor.read_uv()
                
                # 3. Handle invalid UV reading
                if not is_valid:
                    logger.warning(f"Invalid UV reading: {error_msg}")
                    error_packet = self.create_error_packet("UV_INVALID", error_msg)
                    self.lora.send(error_packet)
                    self.blink_led_error(duration=2.0)
                    self.set_led(LED_NORMAL_STATE)
                    
                    # Sleep remaining interval
                    elapsed = time.time() - loop_start
                    sleep_time = max(0, interval - elapsed)
                    time.sleep(sleep_time)
                    continue
                
                # 4. Send UV packet with ACK/NACK logic
                self.send_uv_with_ack(uv_index)
                
                self.set_led(LED_NORMAL_STATE)
                
                # 5. Sleep remaining interval, polling for CONFIG
                elapsed = time.time() - loop_start
                sleep_time = max(0, interval - elapsed)
                
                # Break sleep into chunks for CONFIG polling
                sleep_chunk = 1.0
                slept = 0
                while slept < sleep_time:
                    chunk = min(sleep_chunk, sleep_time - slept)
                    time.sleep(chunk)
                    slept += chunk
                    self.poll_for_config_update()
                
            except KeyboardInterrupt:
                logger.info("Main loop interrupted by user")
                break
            except Exception as e:
                logger.error(f"Unexpected error in main loop: {e}")
                self.blink_led_error(duration=2.0)
                time.sleep(5)
    
    # ========================================================================
    # INITIALIZATION AND STARTUP
    # ========================================================================
    
    def initialize_all(self) -> bool:
        """Initialize all subsystems"""
        logger.info("=" * 60)
        logger.info("Sensor Station Starting")
        logger.info(f"Sensor ID: {SENSOR_ID}")
        logger.info("=" * 60)
        
        # Initialize LED first
        if not self.init_led():
            logger.warning("LED initialization failed - continuing without LED")
        
        # Initialize LoRa
        if not self.lora.initialize():
            self.handle_critical_error("LORA_INIT_FAIL", "LoRa initialization failed")
            return False
        
        # Initialize UV sensor
        if not self.uv_sensor.initialize():
            self.handle_critical_error("ADC_INIT_FAIL", "UV sensor initialization failed")
            return False
        
        # Wait for initial CONFIG
        if not self.wait_for_initial_config():
            self.handle_critical_error("CONFIG_NOT_RECEIVED", "Initial CONFIG not received")
            return False
        
        logger.info("All subsystems initialized successfully")
        return True
    
    def run(self):
        """Main entry point"""
        if not self.initialize_all():
            logger.critical("Initialization failed, entering error state")
            # Stay alive in error state
            try:
                while True:
                    time.sleep(60)
            except KeyboardInterrupt:
                logger.info("Shutdown requested")
            return
        
        # Start main loop
        try:
            logger.info(f"Starting main loop with interval: {self.config.time_interval_s}s")
            self.main_loop()
        except Exception as e:
            logger.critical(f"Fatal error in main: {e}")
            self.handle_critical_error("FATAL_ERROR", str(e))
        finally:
            self.cleanup()
    
    def cleanup(self):
        """Cleanup all resources"""
        logger.info("Sensor Station shutting down")
        self.stop_event.set()
        self.set_led(False)
        self.lora.cleanup()
        self.uv_sensor.cleanup()


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point"""
    station = SensorStation()
    station.run()


if __name__ == "__main__":
    main()