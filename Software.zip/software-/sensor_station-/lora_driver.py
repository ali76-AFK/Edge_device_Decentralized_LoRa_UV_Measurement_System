import time
import logging
import board
import busio
import digitalio
import adafruit_rfm9x
from typing import Optional
from hardware_config import LORA_FREQUENCY_MHZ, LORA_CS_PIN, LORA_RESET_PIN

logger = logging.getLogger(__name__)

class LoRaDriver:
    # Define the missing timeout constant here
    RX_TIMEOUT = 5.0  

    def __init__(self):
        self.rfm9x = None
        self._is_initialized = False
        
    def initialize(self) -> bool:
        """Initialize LoRa radio module with retry logic"""
        # Initialize SPI only ONCE to avoid 'Pin in use' errors during retries
        try:
            spi = busio.SPI(board.SCK, MOSI=board.MOSI, MISO=board.MISO)
        except Exception as e:
            logger.critical(f"Failed to initialize SPI bus: {e}")
            return False

        # Retry logic for the LoRa Radio itself
        for attempt in range(1, 6):
            try:
                # Dynamic pin assignment from hardware_config (Expects integers, e.g., 25)
                # Ensure hardware_config.py has LORA_CS_PIN = 25, not board.D25
                cs = digitalio.DigitalInOut(getattr(board, f"D{LORA_CS_PIN}"))
                reset = digitalio.DigitalInOut(getattr(board, f"D{LORA_RESET_PIN}"))
                
                self.rfm9x = adafruit_rfm9x.RFM9x(spi, cs, reset, LORA_FREQUENCY_MHZ)
                self.rfm9x.tx_power = 14
                self.rfm9x.enable_crc = True
                
                self._is_initialized = True
                logger.info(f"LoRa initialized on {LORA_FREQUENCY_MHZ} MHz")
                return True
            except Exception as e:
                logger.error(f"LoRa init failed (Attempt {attempt}/5): {e}")
                time.sleep(2)
        
        return False
    
    @property
    def is_initialized(self) -> bool:
        """Check if LoRa is initialized"""
        return self._is_initialized
    
    def send(self, packet_bytes: bytes) -> bool:
        """Send packet via LoRa"""
        if not self._is_initialized:
            logger.error("LoRa not initialized, cannot send")
            return False
        
        try:
            self.rfm9x.send(packet_bytes)
            logger.debug(f"Sent {len(packet_bytes)} bytes via LoRa")
            return True
        except Exception as e:
            logger.error(f"Failed to send packet: {e}")
            return False
    
    def receive(self, timeout: float = None) -> Optional[bytes]:
        """Receive packet via LoRa with timeout"""
        if not self._is_initialized:
            logger.error("LoRa not initialized, cannot receive")
            return None
        
        # Now valid because RX_TIMEOUT is defined in the class
        if timeout is None:
            timeout = self.RX_TIMEOUT
        
        try:
            packet_bytes = self.rfm9x.receive(timeout=timeout)
            if packet_bytes is not None:
                logger.debug(f"Received {len(packet_bytes)} bytes via LoRa")
            return packet_bytes
        except Exception as e:
            logger.error(f"Failed to receive packet: {e}")
            return None
    
    def send_with_ack(self, packet_bytes: bytes, max_retries: int, 
                      ack_check_func, ack_timeout: float = 5.0) -> bool:
        """Send packet and wait for ACK with retry logic"""
        for attempt in range(1, max_retries + 1):
            logger.info(f"Transmission attempt {attempt}/{max_retries}")
            
            # Send packet
            if not self.send(packet_bytes):
                logger.warning(f"Send failed on attempt {attempt}")
                time.sleep(1)
                continue
            
            # Wait for response
            response = self.receive(timeout=ack_timeout)
            
            if response is None:
                logger.warning(f"No response received on attempt {attempt}")
                time.sleep(1)
                continue
            
            # Check if it's an ACK
            if ack_check_func(response):
                logger.info(f"ACK received on attempt {attempt}")
                return True
            else:
                logger.warning(f"NACK or unexpected response on attempt {attempt}")
                time.sleep(1)
        
        logger.error(f"Failed to receive ACK after {max_retries} attempts")
        return False
    
    def get_rssi(self) -> Optional[float]:
        """Get last packet RSSI"""
        if not self._is_initialized:
            return None
        
        try:
            return self.rfm9x.last_rssi
        except:
            return None
    
    def cleanup(self):
        """Cleanup resources"""
        # Note: adafruit_rfm9x does not require explicit cleanup
        self._is_initialized = False
        logger.info("LoRa driver cleanup complete")