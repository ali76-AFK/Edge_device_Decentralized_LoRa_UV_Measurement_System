#!/usr/bin/env python3

import logging
import time

from cds_backend_sim import CentralDataSystemBackend
from ui_tk import CDSApp


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    logger = logging.getLogger(__name__)

    backend = CentralDataSystemBackend()

    logger.info("Attempting to synchronize with Sensor Station (SIM)...")

    start_success = False
    for attempt in range(1, 6):
        logger.info(
            f"Broadcasting startup configuration (Attempt {attempt}/5)..."
        )
        if backend.send_config(backend.config):
            logger.info("SUCCESS: Sensor Station synchronized (SIM)!")
            start_success = True
            break
        else:
            logger.warning("No ACK received. Retrying...")
            time.sleep(1)

    if not start_success:
        logger.warning(
            "Could not sync with sensor (SIM). "
            "Starting GUI anyway (Sensor will use defaults)."
        )

    try:
        app = CDSApp(backend)
        app.mainloop()
    finally:
        backend.stop()


if __name__ == "__main__":
    main()
