#!/usr/bin/env python3

import time
import threading
import logging
import socket
from collections import deque
from datetime import datetime
from dataclasses import dataclass
from typing import Optional

from protocol import PacketType, encode_packet, decode_packet, ConfigData
from blind_actuator import BlindActuator
from hardware_config_sim import LORA_FREQUENCY_MHZ


logging.getLogger(__name__)


DEFAULT_CONFIG = ConfigData(
    time_interval_s=5.0,
    uv_threshold=6.0,
    offset_corr_v=0.0,
    smoothing_alpha=0.3,
)


@dataclass
class ErrorPacket:
    timestamp: datetime
    error_type: str
    pkt_type: Optional[str]
    reason: str
    raw_hex: str


class LoRaCommSim:
    """
    Simulated LoRaComm for central_data_station.

    Uses a TCP server socket to accept a single connection from the
    simulated sensor node. Packets are sent as length-prefixed frames:

        [4 byte big-endian length][packet bytes]
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 6000):
        self.host = host
        self.port = port

        self._srv_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._srv_sock.bind((self.host, self.port))
        self._srv_sock.listen(1)
        self._srv_sock.settimeout(1.0)

        logging.info(
            f"[SIM-LoRa] CDS listening for sensor on "
            f"{self.host}:{self.port} (freq {LORA_FREQUENCY_MHZ} MHz)"
        )

        while True:
            try:
                conn, addr = self._srv_sock.accept()
                logging.info(f"[SIM-LoRa] Sensor connected from {addr}")
                conn.settimeout(1.0)
                self._conn = conn
                break
            except socket.timeout:
                logging.info("[SIM-LoRa] Waiting for sensor to connect...")
                time.sleep(1.0)

        self.last_rssi: Optional[int] = None
        self.last_snr: Optional[float] = None

    def _recv_exact(self, n: int, timeout_s: float) -> Optional[bytes]:
        self._conn.settimeout(timeout_s)
        data = b""
        try:
            while len(data) < n:
                chunk = self._conn.recv(n - len(data))
                if not chunk:
                    return None
                data += chunk
            return data
        except socket.timeout:
            return None
        except OSError:
            return None

    def send(self, payload: bytes) -> None:
        """
        Send a packet (bytes) to the sensor.
        """
        if not hasattr(self, "_conn"):
            logging.warning("[SIM-LoRa] No connection; cannot send")
            return

        frame = len(payload).to_bytes(4, "big") + payload
        try:
            self._conn.sendall(frame)
            logging.debug(f"[SIM-LoRa] TX {len(payload)} bytes")
        except OSError as e:
            logging.warning(f"[SIM-LoRa] Send failed: {e}")

    def receive(self, timeout_s: float = 0.5) -> Optional[bytes]:
        """
        Receive a single packet from the sensor, or None on timeout.
        """
        if not hasattr(self, "_conn"):
            return None

        length_bytes = self._recv_exact(4, timeout_s)
        if length_bytes is None:
            return None

        length = int.from_bytes(length_bytes, "big")
        if length <= 0 or length > 65535:
            logging.warning(f"[SIM-LoRa] Invalid length: {length}")
            return None

        data = self._recv_exact(length, timeout_s)
        if data is None:
            return None

        self.last_rssi = -42
        self.last_snr = 9.5

        logging.debug(f"[SIM-LoRa] RX {len(data)} bytes")
        return data

    def close(self):
        try:
            if hasattr(self, "_conn"):
                self._conn.close()
        finally:
            self._srv_sock.close()
            logging.info("[SIM-LoRa] Closed sockets")


class CentralDataSystemBackend:
    def __init__(self, config: ConfigData | None = None):
        self.config = config or DEFAULT_CONFIG

        self.lora = LoRaCommSim()
        self.blinds = BlindActuator()

        self.lora_lock = threading.Lock()

        self.uv_log: deque[tuple[datetime, float]] = deque(maxlen=256)
        self.error_log: deque[ErrorPacket] = deque(maxlen=256)

        self.last_packet_time: datetime | None = datetime.now()
        self.last_packet_interval: float | None = None
        self.last_rssi: int | None = None
        self.last_snr: float | None = None
        self.packets_rx = 0
        self.packets_crc_error = 0

        self._config_ack_event = threading.Event()
        self._sensor_is_active = threading.Event()

        self._stop = threading.Event()

        self._rx_thread = threading.Thread(target=self._rx_loop, daemon=True)
        self._rx_thread.start()

        self._watchdog_thread = threading.Thread(
            target=self._watchdog_loop, daemon=True
        )
        self._watchdog_thread.start()

    def _extract_error_packet(
        self,
        error_type: str,
        reason: str,
        raw: bytes | None = None,
        pkt_type: PacketType | None = None,
    ) -> None:
        raw_hex = raw.hex() if isinstance(raw, (bytes, bytearray)) else ""
        pkt_type_str = pkt_type.value if pkt_type else None
        self.error_log.append(
            ErrorPacket(datetime.now(), error_type, pkt_type_str, reason, raw_hex)
        )

    def get_error_log(self) -> list[dict]:
        return [
            {
                "timestamp": ep.timestamp,
                "error_type": ep.error_type,
                "pkt_type": ep.pkt_type,
                "reason": ep.reason,
                "raw_hex": ep.raw_hex,
            }
            for ep in list(self.error_log)
        ]

    def _update_telemetry(self):
        now = datetime.now()
        if self.last_packet_time:
            self.last_packet_interval = (now - self.last_packet_time).total_seconds()
        self.last_packet_time = now
        try:
            self.last_rssi = self.lora.last_rssi
            self.last_snr = self.lora.last_snr
        except Exception:
            pass

    def _safe_send(self, payload: bytes):
        with self.lora_lock:
            self.lora.send(payload)

    def _handle_uv_packet(self, payload: dict, crc_ok: bool, raw: bytes):
        if not crc_ok:
            logging.warning("UV packet CRC error")
            self.packets_crc_error += 1
            self._extract_error_packet(
                "CRC_ERROR", "CRC mismatch in UV_DATA", raw, PacketType.UV_DATA
            )
            self._safe_send(encode_packet(PacketType.UV_NACK, {"reason": "crc"}))
            return

        try:
            uv_index = float(payload["uv_index"])
        except (KeyError, ValueError) as e:
            logging.warning("Malformed UV payload: %s", e)
            self._extract_error_packet(
                "BAD_PAYLOAD", f"Invalid uv_index: {e}", raw, PacketType.UV_DATA
            )
            self._safe_send(
                encode_packet(PacketType.UV_NACK, {"reason": "bad_payload"})
            )
            return

        self._update_telemetry()
        self._sensor_is_active.set()

        self.packets_rx += 1
        self.uv_log.append((self.last_packet_time, uv_index))
        logging.info("Received UV index: %.2f", uv_index)

        if uv_index >= self.config.uv_threshold:
            self.blinds.close()
        else:
            self.blinds.open()

        self._safe_send(encode_packet(PacketType.UV_ACK, {"ok": True}))

    def _watchdog_loop(self):
        last_warning_time = 0.0
        while not self._stop.is_set():
            time.sleep(1.0)
            if not self.last_packet_time:
                continue

            age = (datetime.now() - self.last_packet_time).total_seconds()
            if age > 15.0:
                if time.time() - last_warning_time > 10.0:
                    logging.warning(
                        f"SENSOR TIMEOUT: No data received for {int(age)} seconds!"
                    )
                    last_warning_time = time.time()

    def _rx_loop(self):
        while not self._stop.is_set():
            with self.lora_lock:
                packet = self.lora.receive(timeout_s=0.5)
            time.sleep(0.05)

            if packet is None:
                continue

            try:
                pkt_type, payload, crc_ok = decode_packet(packet)
            except Exception as e:
                logging.warning("Decode error: %s", e)
                continue

            if not crc_ok:
                self.packets_crc_error += 1
                self._extract_error_packet(
                    "CRC_ERROR", "CRC Check Failed", packet, None
                )
                continue

            if pkt_type == PacketType.UV_DATA:
                self._handle_uv_packet(payload, True, packet)

            elif pkt_type == PacketType.CONFIG_ACK:
                logging.info("Received CONFIG_ACK from sensor")
                self._config_ack_event.set()
                self._sensor_is_active.set()

            elif pkt_type == PacketType.CONFIG_NACK:
                logging.warning("Received CONFIG_NACK from sensor")

            elif pkt_type == PacketType.ERROR:
                error_code = payload.get("error_code", "UNKNOWN")
                msg = payload.get("message", "No message")
                logging.warning(f"REMOTE SENSOR ERROR: {error_code} - {msg}")
                self._extract_error_packet(
                    f"SENSOR_{error_code}", msg, packet, pkt_type
                )

            else:
                logging.info("Unexpected packet type: %s", pkt_type)
                self._extract_error_packet(
                    "UNEXPECTED_TYPE", f"Type: {pkt_type}", packet, pkt_type
                )

    def send_config(self, new_cfg: ConfigData) -> bool:
        self.config = new_cfg
        pkt = encode_packet(PacketType.CONFIG, new_cfg.to_dict())

        self._config_ack_event.clear()

        if self._sensor_is_active.is_set():
            logging.info("Sensor active. Skipping redundant config sync.")
            return True

        logging.info("Sending CONFIG packet...")
        with self.lora_lock:
            self.lora.send(pkt)

        for _ in range(30):
            if self._config_ack_event.is_set():
                return True
            if self._sensor_is_active.is_set():
                logging.info(
                    "Received UV data while waiting for ACK. Sync success."
                )
                return True
            time.sleep(0.1)

        logging.warning("CONFIG_ACK timeout")
        return False

    def get_status(self) -> dict:
        now = datetime.now()
        age = (
            (now - self.last_packet_time).total_seconds()
            if self.last_packet_time
            else None
        )
        return {
            "uv_threshold": self.config.uv_threshold,
            "interval_s": self.config.time_interval_s,
            "last_uv": self.uv_log[-1][1] if self.uv_log else None,
            "blind_closed": self.blinds.closed,
            "packets_rx": self.packets_rx,
            "crc_errors": self.packets_crc_error,
            "age_s": age,
            "error_count": len(self.error_log),
        }

    def stop(self):
        self._stop.set()
        self._rx_thread.join(timeout=1.0)
        self._watchdog_thread.join(timeout=1.0)
        self.blinds.stop()
        self.lora.close()
        logging.info("CDS backend stopped")
