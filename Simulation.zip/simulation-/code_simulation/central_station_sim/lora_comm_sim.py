#!/usr/bin/env python3

import time
import logging
import socket
from typing import Optional

from hardware_config_sim import LORA_FREQUENCY_MHZ


class LoRaCommSim:
    """
    Simulated LoRaComm.

    Central side: run as a TCP server (already done inside cds_backend_sim.py).
    Sensor side: will use a TCP client (in the sensor simulation code).

    This version is for the *sensor station* (client).
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 6000):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(5.0)

        logging.info(
            f"[SIM-LoRa] Sensor connecting to CDS at {self.host}:{self.port} "
            f"(freq {LORA_FREQUENCY_MHZ} MHz)"
        )

        while True:
            try:
                self.sock.connect((self.host, self.port))
                logging.info("[SIM-LoRa] Sensor connected to CDS")
                break
            except OSError:
                logging.info("[SIM-LoRa] Waiting for CDS to listen...")
                time.sleep(1.0)

        self.sock.settimeout(1.0)
        self.last_rssi: Optional[int] = None
        self.last_snr: Optional[float] = None

    def _recv_exact(self, n: int, timeout_s: float) -> Optional[bytes]:
        self.sock.settimeout(timeout_s)
        data = b""
        try:
            while len(data) < n:
                chunk = self.sock.recv(n - len(data))
                if not chunk:
                    return None
                data += chunk
            return data
        except socket.timeout:
            return None
        except OSError:
            return None

    def send(self, payload: bytes) -> None:
        frame = len(payload).to_bytes(4, "big") + payload
        try:
            self.sock.sendall(frame)
            logging.debug(f"[SIM-LoRa] Sensor TX {len(payload)} bytes")
        except OSError as e:
            logging.warning(f"[SIM-LoRa] Sensor send failed: {e}")

    def receive(self, timeout_s: float):
        length_bytes = self._recv_exact(4, timeout_s)
        if length_bytes is None:
            return None

        length = int.from_bytes(length_bytes, "big")
        if length <= 0 or length > 65535:
            logging.warning(f"[SIM-LoRa] Sensor got invalid length: {length}")
            return None

        data = self._recv_exact(length, timeout_s)
        if data is None:
            return None

        # Dummy telemetry for simulation
        self.last_rssi = -45
        self.last_snr = 10.0
        logging.debug(f"[SIM-LoRa] Sensor RX {len(data)} bytes")
        return data

    @property
    def last_rssi_value(self):
        return self.last_rssi

    @property
    def last_snr_value(self):
        return self.last_snr

    def close(self):
        self.sock.close()
        logging.info("[SIM-LoRa] Sensor socket closed")
