#!/usr/bin/env python3

import time
import logging

SERVO_OPEN_ANGLE = 0
SERVO_CLOSED_ANGLE = 90
SERVO_MOVE_DELAY_S = 0.4


class FakeAngularServo:
    """
    Minimal stand-in for gpiozero.AngularServo for simulation.
    Stores the angle and logs movements instead of driving hardware.
    """
    def __init__(self, pin=None, min_angle=0, max_angle=180):
        self.pin = pin
        self.min_angle = min_angle
        self.max_angle = max_angle
        self._angle = None
        logging.info(
            f"[SIM] FakeAngularServo created on pin={pin}, "
            f"min_angle={min_angle}, max_angle={max_angle}"
        )

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, value):
        if value is not None:
            if not (self.min_angle <= value <= self.max_angle):
                logging.warning(
                    f"[SIM] Angle {value} out of range "
                    f"[{self.min_angle}, {self.max_angle}]"
                )
            logging.info(f"[SIM] Servo angle set to {value} degrees")
        self._angle = value

    def detach(self):
        logging.info("[SIM] Servo detached (signal off)")

    def close(self):
        logging.info("[SIM] Servo closed / cleaned up")


class BlindActuator:
    """
    Servo-based blind actuator (SIMULATION version, no gpiozero).
    """

    def __init__(self):
        try:
            self.blind_pin_bcm = "SIM_PIN"
            self.servo = FakeAngularServo(
                self.blind_pin_bcm,
                min_angle=0,
                max_angle=180,
            )
            self.servo.detach()
        except Exception as e:
            logging.error(f"[SIM] Failed to init servo: {e}")
            self.servo = None

        self.closed = False

    def close(self):
        if not self.closed and self.servo:
            self.servo.angle = SERVO_CLOSED_ANGLE
            time.sleep(SERVO_MOVE_DELAY_S)
            self.servo.detach()
            self.closed = True
            logging.info("[SIM] Blind CLOSED")

    def open(self):
        if self.closed and self.servo:
            self.servo.angle = SERVO_OPEN_ANGLE
            time.sleep(SERVO_MOVE_DELAY_S)
            self.servo.detach()
            self.closed = False
            logging.info("[SIM] Blind OPEN")

    def stop(self):
        if self.servo:
            self.servo.close()
            logging.info("[SIM] Blind STOP / cleanup")
