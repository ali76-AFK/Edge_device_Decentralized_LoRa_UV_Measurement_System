# hardware_config_sim.py  (shared by both stations in simulation)

# LoRa Radio Frequency used in both simulated nodes
LORA_FREQUENCY_MHZ = 868.0

# The following pin constants are kept only for compatibility; not used in SIM.
LORA_CS_PIN    = 25
LORA_RESET_PIN = 24
LORA_DIO0_PIN  = 4

BLIND_PIN_BCM  = 25   # Not actually used in sim actuator
LED_PIN_BCM    = 17
