#!/usr/bin/env python3
"""
LoRa driver (SIMULATION) for SENSOR STATION.

Replaces the hardware RFM9x driver with a TCP client that connects
to the central_data_station simulation (cds_backend_sim.py).
"""

import time
import logging
import socket
from typing import Optional

from hardware_config_sim import LORA_FREQUENCY_MHZ

logger = logging.getLogger(__name__)


class LoRaDriver:
    RX_TIMEOUT = 5.0

    def __init__(self, host: str = "127.0.0.1", port: int = 6000):
        self.host = host
        self.port = port
        self.sock: Optional[socket.socket] = None
        self._is_initialized = False
        self.last_rssi: Optional[float] = None
        self.last_snr: Optional[float] = None

    def initialize(self) -> bool:
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(5.0)
            logger.info(
                f"(SIM-LoRa) Sensor connecting to CDS at "
                f"{self.host}:{self.port} (freq {LORA_FREQUENCY_MHZ} MHz)"
            )

            while True:
                try:
                    self.sock.connect((self.host, self.port))
                    break
                except OSError:
                    logger.info("(SIM-LoRa) Waiting for CDS to listen...")
                    time.sleep(1.0)

            self.sock.settimeout(1.0)
            self._is_initialized = True
            logger.info("(SIM-LoRa) Sensor connected to CDS (SIM)")
            return True
        except Exception as e:
            logger.critical(f"(SIM-LoRa) Failed to initialize TCP link: {e}")
            self._is_initialized = False
            return False

    @property
    def is_initialized(self) -> bool:
        return self._is_initialized

    def _recv_exact(self, n: int, timeout: float) -> Optional[bytes]:
        if not self.sock:
            return None
        self.sock.settimeout(timeout)
        data = b""
        try:
            while len(data) < n:
                chunk = self.sock.recv(n - len(data))
                if not chunk:
                    return None
                data += chunk
            return data
        except socket.timeout:
            return None
        except OSError:
            return None

    def send(self, packet_bytes: bytes) -> bool:
        if not self._is_initialized or not self.sock:
            logger.error("(SIM-LoRa) Not initialized, cannot send")
            return False

        frame = len(packet_bytes).to_bytes(4, "big") + packet_bytes
        try:
            self.sock.sendall(frame)
            logger.debug(f"(SIM-LoRa) Sent {len(packet_bytes)} bytes")
            return True
        except OSError as e:
            logger.error(f"(SIM-LoRa) Failed to send packet: {e}")
            return False

    def receive(self, timeout: float = None) -> Optional[bytes]:
        if not self._is_initialized or not self.sock:
            logger.error("(SIM-LoRa) Not initialized, cannot receive")
            return None

        if timeout is None:
            timeout = self.RX_TIMEOUT

        length_bytes = self._recv_exact(4, timeout)
        if length_bytes is None:
            return None

        length = int.from_bytes(length_bytes, "big")
        if length <= 0 or length > 65535:
            logger.warning(f"(SIM-LoRa) Invalid length field: {length}")
            return None

        data = self._recv_exact(length, timeout)
        if data is None:
            return None

        self.last_rssi = -45.0
        self.last_snr = 10.0

        logger.debug(f"(SIM-LoRa) Received {len(data)} bytes")
        return data

    def send_with_ack(
        self,
        packet_bytes: bytes,
        max_retries: int,
        ack_check_func,
        ack_timeout: float = 5.0,
    ) -> bool:
        for attempt in range(1, max_retries + 1):
            logger.info(
                f"(SIM-LoRa) Transmission attempt {attempt}/{max_retries}"
            )

            if not self.send(packet_bytes):
                logger.warning(
                    f"(SIM-LoRa) Send failed on attempt {attempt}"
                )
                time.sleep(1)
                continue

            response = self.receive(timeout=ack_timeout)
            if response is None:
                logger.warning(
                    f"(SIM-LoRa) No response on attempt {attempt}"
                )
                time.sleep(1)
                continue

            if ack_check_func(response):
                logger.info(
                    f"(SIM-LoRa) ACK received on attempt {attempt}"
                )
                return True
            else:
                logger.warning(
                    f"(SIM-LoRa) NACK or unexpected response on "
                    f"attempt {attempt}"
                )
                time.sleep(1)

        logger.error(
            f"(SIM-LoRa) Failed to receive ACK after {max_retries} attempts"
        )
        return False

    def get_rssi(self) -> Optional[float]:
        return self.last_rssi if self._is_initialized else None

    def cleanup(self):
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self._is_initialized = False
        logger.info("(SIM-LoRa) LoRa driver cleanup complete")
