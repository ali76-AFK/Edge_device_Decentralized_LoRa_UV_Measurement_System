#!/usr/bin/env python3
"""
Backend Sensor Module (SIMULATION)
Simulates ADC + UV sensor reading, filtering, and validation.
No board/busio/ADS1115 hardware required.
"""

import time
import logging
import random
from typing import Tuple

logger = logging.getLogger(__name__)


class FakeAnalogIn:
    """
    Simple ADC channel simulator.

    - voltage: returns a slowly varying value between 0.0V and ~1.2V
      (approx UV index 0–12 for sensitivity 0.1 V/UV).
    """

    def __init__(self):
        self._v = 0.2

    @property
    def voltage(self) -> float:
        step = random.uniform(-0.05, 0.05)
        self._v += step
        if self._v < 0.0:
            self._v = 0.0
        if self._v > 1.2:
            self._v = 1.2
        return self._v


class UVSensor:
    """
    UV sensor backend handling ADC reading, filtering, and validation
    SIMULATION version: uses FakeAnalogIn instead of ADS1115.
    """

    ADC_CHANNEL = 0
    ADC_GAIN = 1

    UV_SENSITIVITY = 0.1
    UV_MAX_VALID = 20.0
    UV_MAX_JUMP = 5.0

    def __init__(self):
        self.adc = None
        self.uv_channel = None
        self._is_initialized = False

        self.uv_filtered = None
        self.last_valid_uv = None

        self.offset = 0.0
        self.alpha = 0.3

    def initialize(self) -> bool:
        try:
            self.adc = "FAKE_ADC"
            self.uv_channel = FakeAnalogIn()
            _ = self.uv_channel.voltage
            self._is_initialized = True
            logger.info("UV sensor (SIM) initialized successfully")
            return True
        except Exception as e:
            logger.error(f"UV sensor (SIM) initialization failed: {e}")
            self._is_initialized = False
            return False

    @property
    def is_initialized(self) -> bool:
        return self._is_initialized

    def update_config(self, offset: float, alpha: float):
        self.offset = offset
        self.alpha = alpha
        logger.debug(f"(SIM) UV sensor config updated: offset={offset}V, alpha={alpha}")

    def read_voltage(self) -> float:
        if not self._is_initialized:
            if not self.initialize():
                logger.error("UV sensor (SIM) not initialized")
                return -1.0

        try:
            return self.uv_channel.voltage
        except Exception as e:
            logger.error(f"(SIM) Failed to read UV voltage: {e}")
            self._is_initialized = False
            return -1.0

    def apply_offset_correction(self, voltage: float) -> float:
        return voltage - self.offset

    def apply_low_pass_filter(self, current_value: float) -> float:
        if self.uv_filtered is None:
            self.uv_filtered = current_value
        else:
            self.uv_filtered = (
                self.alpha * current_value + (1 - self.alpha) * self.uv_filtered
            )
        return self.uv_filtered

    def voltage_to_uv_index(self, voltage: float) -> float:
        if voltage < 0:
            return -1.0
        return voltage / self.UV_SENSITIVITY

    def validate_uv_index(self, uv_index: float) -> Tuple[bool, str]:
        if uv_index < 0:
            return False, "Sensor Read Failed (Negative/Offline)"
        if uv_index > self.UV_MAX_VALID:
            return False, f"UV index exceeds maximum ({self.UV_MAX_VALID})"
        if self.last_valid_uv is not None:
            jump = abs(uv_index - self.last_valid_uv)
            if jump > self.UV_MAX_JUMP:
                logger.warning(f"(SIM) Large UV jump detected: {jump:.2f}")
        return True, ""

    def read_uv(self) -> Tuple[float, bool, str]:
        raw_voltage = self.read_voltage()

        if raw_voltage < 0:
            return -1.0, False, "Hardware Failure (SIM UV source)"

        if raw_voltage > 3.3:
            return -1.0, False, f"Sensor Fault: Voltage Too High ({raw_voltage:.2f}V)"

        corrected_voltage = self.apply_offset_correction(raw_voltage)
        filtered_voltage = self.apply_low_pass_filter(corrected_voltage)
        uv_index = self.voltage_to_uv_index(filtered_voltage)

        is_valid, error_msg = self.validate_uv_index(uv_index)

        if is_valid:
            self.last_valid_uv = uv_index
            logger.debug(
                f"(SIM) UV reading: {uv_index:.2f} (voltage: {filtered_voltage:.3f}V)"
            )
        else:
            logger.warning(f"(SIM) Invalid UV reading: {uv_index:.2f} - {error_msg}")

        return uv_index, is_valid, error_msg

    def reset_filter(self):
        self.uv_filtered = None
        logger.debug("(SIM) UV filter reset")

    def cleanup(self):
        self._is_initialized = False
        logger.info("UV sensor (SIM) cleanup complete")
