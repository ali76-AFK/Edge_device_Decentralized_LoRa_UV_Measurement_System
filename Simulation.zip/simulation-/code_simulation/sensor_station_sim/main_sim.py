#!/usr/bin/env python3
"""
Sensor Station Main Application (SIMULATION)
LoRa-based UV Monitoring System - Sensor Pi (no hardware).
"""

import time
import sys
import logging
import threading
from datetime import datetime

from protocol import PacketType, ConfigData, encode_packet, decode_packet
from lora_driver_sim import LoRaDriver
from backend_sensor_sim import UVSensor


SENSOR_ID = "sensor1"

LED_ERROR_BLINK_RATE = 0.2
LED_NORMAL_STATE = True

CONFIG_TIMEOUT = 30
CONFIG_MAX_ATTEMPTS = 3
ACK_TIMEOUT = 5.0

ERROR_LOG_FILE = "sensor_station_errors.log"

DEFAULT_CONFIG = ConfigData(
    time_interval_s=5.0,
    uv_threshold=6.0,
    offset_corr_v=0.0,
    smoothing_alpha=0.3,
    max_retries=3,
)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("sensor_station.log"),
    ],
)
logger = logging.getLogger(__name__)


class SensorStation:
    """Main sensor station controller (SIMULATION)."""

    def __init__(self):
        self.lora = LoRaDriver()
        self.uv_sensor = UVSensor()
        self.led = None  # simulation: logical flag only

        self.config = DEFAULT_CONFIG
        self.config_lock = threading.Lock()

        self.error_state = False
        self.error_log = []

        self.stop_event = threading.Event()
        self.error_led_thread = None

    # LED CONTROL (SIM)

    def init_led(self) -> bool:
        """Initialize LED (SIM: just a logical flag)."""
        self.led = True
        logger.info("(SIM) LED initialized (logical)")
        return True

    def set_led(self, state: bool):
        """Set LED state (SIM: log only)."""
        logger.info(f"(SIM) LED set to {'ON' if state else 'OFF'}")

    def blink_led_error(self, duration: float = 5.0):
        """Blink LED rapidly to indicate error (SIM)."""
        end_time = time.time() + duration
        while time.time() < end_time:
            self.set_led(True)
            time.sleep(LED_ERROR_BLINK_RATE)
            self.set_led(False)
            time.sleep(LED_ERROR_BLINK_RATE)

    def _led_error_loop(self):
        """Background thread for continuous error LED blinking (SIM)."""
        while not self.stop_event.is_set():
            self.set_led(True)
            time.sleep(LED_ERROR_BLINK_RATE)
            self.set_led(False)
            time.sleep(LED_ERROR_BLINK_RATE)

    def start_error_led(self):
        """Start continuous error LED blinking in background (SIM)."""
        if self.error_led_thread is None or not self.error_led_thread.is_alive():
            self.stop_event.clear()
            self.error_led_thread = threading.Thread(
                target=self._led_error_loop, daemon=True
            )
            self.error_led_thread.start()

    # ERROR HANDLING

    def log_error(self, error_code: str, message: str):
        timestamp = datetime.now().isoformat()
        error_entry = f"{timestamp} | {error_code} | {message}\n"
        try:
            with open(ERROR_LOG_FILE, "a") as f:
                f.write(error_entry)
            self.error_log.append(
                {"ts": timestamp, "code": error_code, "msg": message}
            )
            logger.error(f"Error logged: {error_code} - {message}")
        except Exception as e:
            logger.error(f"Failed to write error log: {e}")

    def handle_critical_error(self, error_code: str, message: str):
        self.error_state = True
        logger.critical(f"Critical error: {error_code} - {message}")
        self.log_error(error_code, message)
        self.start_error_led()
        if self.lora.is_initialized and error_code != "LORA_INIT_FAIL":
            try:
                error_packet = self.create_error_packet(error_code, message)
                self.lora.send(error_packet)
            except Exception:
                pass
        logger.info("Entering error state - LED blinking continuously")

    # PACKET CREATION

    def create_uv_packet(self, uv_index: float) -> bytes:
        timestamp = int(time.time())
        payload = {
            "sensor_id": SENSOR_ID,
            "uv_index": round(uv_index, 2),
            "timestamp": timestamp,
        }
        return encode_packet(PacketType.UV_DATA, payload)

    def create_error_packet(self, error_code: str, message: str) -> bytes:
        timestamp = int(time.time())
        payload = {
            "sensor_id": SENSOR_ID,
            "error_code": error_code,
            "message": message,
            "timestamp": timestamp,
        }
        return encode_packet(PacketType.ERROR, payload)

    def create_config_ack(self) -> bytes:
        payload = {"sensor_id": SENSOR_ID}
        return encode_packet(PacketType.CONFIG_ACK, payload)

    def create_config_nack(self, reason: str) -> bytes:
        payload = {"sensor_id": SENSOR_ID, "reason": reason}
        return encode_packet(PacketType.CONFIG_NACK, payload)

    # CONFIG HANDLING

    def parse_config_packet(self, payload: dict) -> ConfigData | None:
        try:
            config = ConfigData.from_dict(payload)
            if config.time_interval_s <= 0 or config.time_interval_s > 3600:
                logger.error("Invalid interval value")
                return None
            if config.smoothing_alpha <= 0 or config.smoothing_alpha > 1:
                logger.error("Invalid alpha value")
                return None
            if config.max_retries < 1 or config.max_retries > 10:
                logger.error("Invalid max_retries value")
                return None
            logger.info(
                "Parsed CONFIG: interval=%ss, alpha=%.2f, offset=%.3fV",
                config.time_interval_s,
                config.smoothing_alpha,
                config.offset_corr_v,
            )
            return config
        except Exception as e:
            logger.error(f"Failed to parse CONFIG: {e}")
            return None

    def apply_config(self, config: ConfigData):
        with self.config_lock:
            self.config = config
        self.uv_sensor.update_config(config.offset_corr_v, config.smoothing_alpha)
        logger.info(f"Applied new configuration: {config.to_dict()}")

    def wait_for_initial_config(self) -> bool:
        for attempt in range(1, CONFIG_MAX_ATTEMPTS + 1):
            logger.info(
                "Waiting for CONFIG packet (attempt %d/%d)...",
                attempt,
                CONFIG_MAX_ATTEMPTS,
            )
            packet_bytes = self.lora.receive(timeout=CONFIG_TIMEOUT)
            if packet_bytes is None:
                logger.warning("CONFIG timeout on attempt %d", attempt)
                self.blink_led_error(duration=2.0)
                continue

            pkt_type, payload, crc_ok = decode_packet(packet_bytes)
            if not crc_ok:
                logger.warning("Received packet with invalid CRC")
                continue

            if pkt_type == PacketType.CONFIG:
                config = self.parse_config_packet(payload)
                if config:
                    self.apply_config(config)
                    self.lora.send(self.create_config_ack())
                    logger.info("Initial CONFIG received and applied")
                    self.set_led(LED_NORMAL_STATE)
                    return True
                else:
                    self.lora.send(self.create_config_nack("Invalid format"))
                    continue
            else:
                logger.warning(
                    "Unexpected packet type (waiting for CONFIG): %s", pkt_type
                )

        logger.warning(
            "Failed to receive valid CONFIG after %d attempts. "
            "Using DEFAULT_CONFIG.",
            CONFIG_MAX_ATTEMPTS,
        )
        self.set_led(LED_NORMAL_STATE)
        return True

    def poll_for_config_update(self) -> bool:
        packet_bytes = self.lora.receive(timeout=0.1)
        if packet_bytes is None:
            return False

        pkt_type, payload, crc_ok = decode_packet(packet_bytes)
        if not crc_ok:
            return False

        if pkt_type == PacketType.CONFIG:
            logger.info("CONFIG update received during runtime")
            config = self.parse_config_packet(payload)
            if config:
                self.apply_config(config)
                self.lora.send(self.create_config_ack())
                logger.info("Runtime CONFIG update applied")
                return True
            else:
                self.lora.send(self.create_config_nack("Invalid format"))
        return False

    # UV TRANSMISSION

    def check_ack(self, response_bytes: bytes) -> bool:
        pkt_type, payload, crc_ok = decode_packet(response_bytes)
        if not crc_ok:
            return False
        return pkt_type == PacketType.UV_ACK

    def send_uv_with_ack(self, uv_index: float) -> bool:
        with self.config_lock:
            max_retries = self.config.max_retries
        uv_packet = self.create_uv_packet(uv_index)
        success = self.lora.send_with_ack(
            uv_packet,
            max_retries,
            self.check_ack,
            ACK_TIMEOUT,
        )
        if not success:
            logger.error("Failed to receive ACK for UV packet")
            error_packet = self.create_error_packet(
                "NO_ACK", "UV ACK failed after retries"
            )
            self.lora.send(error_packet)
            self.log_error(
                "NO_ACK",
                f"UV packet failed after {max_retries} attempts",
            )
            self.blink_led_error(duration=3.0)
        return success

    # MAIN LOOP

    def main_loop(self):
        logger.info("Entering main operational loop (SIM)")
        self.set_led(LED_NORMAL_STATE)

        while not self.error_state:
            try:
                loop_start = time.time()
                with self.config_lock:
                    interval = self.config.time_interval_s

                self.poll_for_config_update()

                uv_index, is_valid, error_msg = self.uv_sensor.read_uv()

                if not is_valid:
                    logger.warning("Invalid UV reading: %s", error_msg)
                    error_packet = self.create_error_packet("UV_INVALID", error_msg)
                    self.lora.send(error_packet)
                    self.blink_led_error(duration=2.0)
                    self.set_led(LED_NORMAL_STATE)
                    elapsed = time.time() - loop_start
                    sleep_time = max(0, interval - elapsed)
                    time.sleep(sleep_time)
                    continue

                self.send_uv_with_ack(uv_index)
                self.set_led(LED_NORMAL_STATE)

                elapsed = time.time() - loop_start
                sleep_time = max(0, interval - elapsed)

                sleep_chunk = 1.0
                slept = 0
                while slept < sleep_time:
                    chunk = min(sleep_chunk, sleep_time - slept)
                    time.sleep(chunk)
                    slept += chunk
                    self.poll_for_config_update()

            except KeyboardInterrupt:
                logger.info("Main loop interrupted by user")
                break
            except Exception as e:
                logger.error("Unexpected error in main loop: %s", e)
                self.blink_led_error(duration=2.0)
                time.sleep(5)

    # INITIALIZATION AND STARTUP

    def initialize_all(self) -> bool:
        logger.info("=" * 60)
        logger.info("Sensor Station Starting (SIM)")
        logger.info("Sensor ID: %s", SENSOR_ID)
        logger.info("=" * 60)

        if not self.init_led():
            logger.warning("LED init failed - continuing without LED")

        if not self.lora.initialize():
            self.handle_critical_error("LORA_INIT_FAIL", "LoRa initialization failed")
            return False

        if not self.uv_sensor.initialize():
            self.handle_critical_error("ADC_INIT_FAIL", "UV sensor initialization failed")
            return False

        if not self.wait_for_initial_config():
            self.handle_critical_error("CONFIG_NOT_RECEIVED", "Initial CONFIG not received")
            return False

        logger.info("All subsystems initialized successfully (SIM)")
        return True

    def run(self):
        if not self.initialize_all():
            logger.critical("Initialization failed, entering error state")
            try:
                while True:
                    time.sleep(60)
            except KeyboardInterrupt:
                logger.info("Shutdown requested")
            return

        try:
            logger.info(
                "Starting main loop with interval: %ss", self.config.time_interval_s
            )
            self.main_loop()
        except Exception as e:
            logger.critical("Fatal error in main: %s", e)
            self.handle_critical_error("FATAL_ERROR", str(e))
        finally:
            self.cleanup()

    def cleanup(self):
        logger.info("Sensor Station shutting down (SIM)")
        self.stop_event.set()
        self.set_led(False)
        self.lora.cleanup()
        self.uv_sensor.cleanup()


def main():
    station = SensorStation()
    station.run()


if __name__ == "__main__":
    main()
