# hardware_config.py for SENSOR STATION

# LoRa Radio Frequency
LORA_FREQUENCY_MHZ = 868.0

# RFM95W Wiring (BCM Pin Numbers)
LORA_CS_PIN    = 25  # GPIO 25
LORA_RESET_PIN = 24  # GPIO 24
LORA_DIO0_PIN  = 4   # GPIO 5 (Often needed for IRQ)

# Actuator / Sensor Pins
BLIND_PIN_BCM  = None # Not used on Sensor
LED_PIN_BCM    = 17   # Status LED


